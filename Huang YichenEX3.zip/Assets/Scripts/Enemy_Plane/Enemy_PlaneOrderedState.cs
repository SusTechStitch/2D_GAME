using System.Collections.Generic;
using UnityEngine;

public class Enemy_PlaneOrderedState : EnemyState
{
    private Enemy_Plane enemy_plane;
    public Enemy_PlaneOrderedState(Enemy enemy, EnemyStateMachine stateMachine, string animBoolName , Enemy_Plane _enemyPlane): base(enemy, stateMachine, animBoolName)
    {
        this.enemy_plane = _enemyPlane;
    }

    public override void Enter()
    {
        base.Enter();
        if (enemy_plane.currentTarget == null)
        {
            SetFirstTarget();
        }
    }

    public override void Exit()
    {
        base.Exit();
    }

    public override void Update()
    {
        base.Update();

        if (HasReachedTarget())
        {
            SetNextTarget();
        }

        if (Input.GetKeyDown(KeyCode.J))
        {
            StateMachine.ChangeState(enemy_plane.RandomState);
        }
    }

    public void SetNextTarget()
    {
        if (enemy_plane.currentTarget != null)
        {
            Transform nextTarget = WaypointManager.Instance.GetNextOrderedWaypoint(enemy_plane.currentTarget);
            enemy_plane.SetTarget(nextTarget);
        }
    }

    private void SetFirstTarget()
    {
        enemy_plane.SetTarget(WaypointManager.Instance.GetRandomWaypoint());
    }

    private bool HasReachedTarget()
    {
        if (enemy_plane.currentTarget == null) return false;

        return Vector2.Distance(
            enemy_plane.transform.position,
            enemy_plane.currentTarget.position
        ) <= enemy_plane.waypointReachedDistance;
    }

}