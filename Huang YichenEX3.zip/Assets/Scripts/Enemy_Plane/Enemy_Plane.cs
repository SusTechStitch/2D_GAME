using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Plane : Enemy
{

    [Header("�ƶ�����")]
    public float moveSpeed = 40f;
    public float waypointReachedDistance = 25f;

    [Header("ת������")]
    public float turnRate = 0.03f; 

    [HideInInspector] public Transform currentTarget;

    public float rotationSmoothness = 60f;


    #region States
    public Enemy_PlaneOrderedState OrderedState { get; private set; }
    public Enemy_PlaneRandomState RandomState { get; private set; }
    #endregion

    protected override void Awake()
    {
        base.Awake();

        OrderedState = new Enemy_PlaneOrderedState(this, stateMachine, "Ordered" , this);
        RandomState = new Enemy_PlaneRandomState(this, stateMachine, "Random" , this);

    }

    protected override void Start()
    {
        base.Start();
        stateMachine.initialize(OrderedState);
    }

    protected override void Update()
    {
        base.Update();
        MoveToTarget();
        if (currentTarget != null)
        {
            PointAtPosition(currentTarget.position, turnRate * Time.deltaTime);
        }
    }

    private void MoveToTarget()
    {
        transform.position += moveSpeed * Time.deltaTime * transform.up;
    }

    private void PointAtPosition(Vector3 targetPosition, float rotationAmount)
    {

        Vector3 directionToTarget = (targetPosition - transform.position).normalized;

        transform.up = Vector3.Slerp(transform.up, directionToTarget, rotationAmount);

    }

    public void SetTarget(Transform target)
    {
        currentTarget = target;
    }

    public void ToggleMovementState()
    {
        if (stateMachine.currentState == OrderedState)
        {
            stateMachine.ChangeState(RandomState);
        }
        else
        {
            stateMachine.ChangeState(OrderedState);
        }
    }

}
