using System.Collections.Generic;
using UnityEngine;

public class WaypointManager : MonoBehaviour
{
    public static WaypointManager Instance;

    public List<Transform> waypoints = new List<Transform>();

    private Camera mainCamera;


    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }


    private void Start()
    {
        mainCamera = Camera.main;
    }


    public Transform GetRandomWaypoint()
    {
        if (waypoints.Count == 0) return null;
        return waypoints[Random.Range(0, waypoints.Count)];
    }

    public Transform GetNextOrderedWaypoint(Transform currentWaypoint)
    {
        if (waypoints.Count == 0) return null;

        int currentIndex = waypoints.IndexOf(currentWaypoint);
        if (currentIndex == -1) return GetRandomWaypoint();

        int nextIndex = (currentIndex + 1) % waypoints.Count;
        return waypoints[nextIndex];
    }

    public Transform GetRandomNextWaypoint(Transform currentWaypoint)
    {
        if (waypoints.Count == 0) return null;
        if (waypoints.Count == 1) return waypoints[0]; 

        List<Transform> availableWaypoints = new List<Transform>(waypoints);
        availableWaypoints.Remove(currentWaypoint);

        return availableWaypoints[Random.Range(0, availableWaypoints.Count)];
    }

    public void WayPointDestroyed(GameObject Waypoint )
    {
        Debug.Log("Destroyed a WayPoint");
    }


    public void SetRandomWayPointPos(Transform waypoint, Vector3 initialPosition)
    {
        if (waypoint == null)
        {
            Debug.LogWarning("Waypoint is null");
            return;
        }

        // �����ڳ�ʼλ�� ��15 ��λ��Χ�ڵ����λ��
        Vector3 newPosition = new Vector3(
            Random.Range(initialPosition.x - 15f, initialPosition.x + 15f),
            Random.Range(initialPosition.y - 15f, initialPosition.y + 15f),
            0f // ����Z�᲻��
        );

        // ����·����λ��
        waypoint.position = newPosition;
    }


}