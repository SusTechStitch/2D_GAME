using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using UnityEngine;

public class WayPointHidedState : WayPointState
{
    private float hideAlpha = 0f;  // ����״̬��͸����

    public WayPointHidedState(WayPoint wayPoint, WayPointStateMachine stateMachine, string animationBoolName): base(wayPoint, stateMachine, animationBoolName)
    {
        this.wayPoint = wayPoint;
    }

    public override void Enter()
    {
        base.Enter();
        wayPoint.SetColor(hideAlpha);
    }

    public override void Exit()
    {
        base.Exit();
    }
    public override void Update()
    {
        base.Update();
        if (Input.GetKeyDown(KeyCode.H))
        {
            statemachine.ChangeState(wayPoint.show);
        }
    }
}
