using UnityEngine;

public class WayPoint : Entity
{
    [Header("����ֵ����")]
    public int maxHits = 4;
    public float alphaMultiplier;


    public int currentHits = 0;

    private Vector3 _initialPosition;

    [Header("�Ӷ������")]
    public Transform childTransform; // ��Inspector�������Ӷ���
    private SpriteRenderer childRenderer;
    private Color initialChildColor;

    #region  States
    public WayPointStateMachine statemachine { get; private set; }
    public WayPointHidedState hided { get; private set; }
    public WayPointShowState show { get; private set; }
    #endregion

    protected override void Awake()
    {
        base.Awake();
        statemachine = new WayPointStateMachine();

        hided = new WayPointHidedState(this, statemachine, "Hided");

        show = new WayPointShowState(this, statemachine, "Show");

        childRenderer = childTransform.GetComponent<SpriteRenderer>();
        if (childRenderer != null)
        {
            initialChildColor = childRenderer.color;
        }
    }
    protected override void Start()
    {
        base.Start();
        statemachine.Initialize(show);
        RecordInitialPosition();
    }

    protected override void Update()
    {
        base.Update();
        statemachine.currentstate.Update();
    }

    public void RecordInitialPosition()
    {
        _initialPosition = transform.position;
    }

    public void SetColor(float alpha)
    {
        if (childRenderer != null)
        {
            Color newColor = new Color(
                initialChildColor.r,
                initialChildColor.g,
                initialChildColor.b,
                alpha
            );
            childRenderer.color = newColor;
        }
    }

    public void TakeHit()
    {
        currentHits++;

        UpdateTransparency();

        if (currentHits >= maxHits)
        {
            MoveToRandomPosition();
        }
    }

    void UpdateTransparency()
    {
        if (base.sr == null)
        {
            return;
        }

        float newAlpha = initialAlpha * Mathf.Pow(alphaMultiplier, currentHits);
        newAlpha = Mathf.Clamp(newAlpha, 0f, 1f);

        base.sr.color = new Color(cr.r, cr.g, cr.b, newAlpha);

    }

    void RenewTransparency()
    {
        if ( base.sr == null )
        {
            return;
        }

        float newAlpha = initialAlpha * Mathf.Pow( 1/alphaMultiplier, 4);
        newAlpha = Mathf.Clamp(newAlpha, 0f, 1f);
        base.sr.color = new Color(cr.r, cr.g, cr.b, newAlpha);

    }
    public void MoveToRandomPosition()
    {
        if (WaypointManager.Instance != null)
        {
            WaypointManager.Instance.SetRandomWayPointPos(this.transform, _initialPosition);
        }
        else
        {
            Debug.LogWarning("WaypointManager instance is null");
        }
        currentHits = 0;
        RenewTransparency();
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("WayPoint"))
        {
            MoveToRandomPosition();
            GameStateManager.Instance.IncrementPlaneCollisions();
        }
    }

}