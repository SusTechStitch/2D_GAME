using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WayPointStateMachine
{
    public WayPointState currentstate { get; private set; }

    public void Initialize(WayPointState _startstate)
    {
        currentstate = _startstate;
        currentstate.Enter();
    }

    public void ChangeState(WayPointState _newstate)
    {
        currentstate.Exit();
        currentstate = _newstate;
        currentstate.Enter();
    }
}
