using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WayPointState
{
    protected WayPointStateMachine statemachine;
    public WayPoint wayPoint;

    protected Rigidbody2D rb;


    protected float xInput;
    protected float yInput;

    private string animeboolname;
    protected float statetimer;

    public WayPointState(WayPoint _waypoint, WayPointStateMachine _statemachine, string _animeboolname)
    {
        this.wayPoint = _waypoint;
        this.statemachine = _statemachine;
        this.animeboolname = _animeboolname;
    }

    public virtual void Enter()
    {
        wayPoint.anime.SetBool(animeboolname, true);
        rb = wayPoint.rb;
    }
    public virtual void Update()
    {
        statetimer -= Time.deltaTime;

        xInput = Input.GetAxisRaw("Horizontal");
        yInput = Input.GetAxisRaw("Vertical");

    }
    public virtual void Exit()
    {
        wayPoint.anime.SetBool(animeboolname, false);
    }
}
