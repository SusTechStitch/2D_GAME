using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using UnityEngine;

public class WayPointShowState : WayPointState
{
    private float showAlpha = 1f;  // ��ʾ״̬��͸����

    public WayPointShowState(WayPoint wayPoint, WayPointStateMachine stateMachine, string animationBoolName): base(wayPoint, stateMachine, animationBoolName)
    {
        this.wayPoint = wayPoint;
    }

    public override void Enter()
    {
        base.Enter();
        wayPoint.SetColor(showAlpha);
    }

    public override void Exit()
    {
        base.Exit();
        wayPoint.currentHits = 0;  
    }
    public override void Update()
    {
        base.Update();
        if (Input.GetKeyDown(KeyCode.H))
        {
            statemachine.ChangeState(wayPoint.hided);
        }
    }
}
