using UnityEngine;

public class Enemy : Entity
{
    [Header("����ֵ����")]
    public int maxHits = 4;
    public float alphaMultiplier;


    private int currentHits = 0;


    public EnemyStateMachine stateMachine { get; private set; }

    protected override void Awake()
    {
        base.Awake();
        stateMachine = new EnemyStateMachine();
    }
    protected override void Start()
    {
        base.Start();
    }

    protected override void Update()
    {
        base.Update();
        stateMachine.currentState.Update();

    }

    public void TakeHit()
    {
        currentHits++;

        UpdateTransparency();

        if (currentHits >= maxHits)
        {
            DestroyEnemy();
        }
    }

    void UpdateTransparency()
    {
        if (sr == null)
        {
            return;
        }

        float newAlpha = initialAlpha * Mathf.Pow(alphaMultiplier, currentHits);
        newAlpha = Mathf.Clamp(newAlpha, 0f, 1f);

        sr.color = new Color(cr.r, cr.g, cr.b, newAlpha);

    }

    void DestroyEnemy()
    {
        if (EnemyManager.Instance != null)
        {
            EnemyManager.Instance.EnemyDestroyed(gameObject);
        }

        Destroy(gameObject);
        GameStateManager.Instance.IncrementEnemiesDestroyed();
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Plane"))
        {
            DestroyEnemy();
            GameStateManager.Instance.IncrementPlaneCollisions();
        }
    }
}