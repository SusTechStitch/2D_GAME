using UnityEngine;
using System.Collections.Generic;

public class EnemyManager : MonoBehaviour
{
    [Header("��������")]
    public GameObject enemyPrefab;
    public int maxEnemies = 10;

    private List<GameObject> activeEnemies = new List<GameObject>();
    private Camera mainCamera;

    public static EnemyManager Instance { get; private set; }

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            Instance = this;
        }
    }

    void Start()
    {
        mainCamera = Camera.main;
        InitializeEnemies();
    }

    void Update()
    {
        if (activeEnemies.Count < maxEnemies)
        {
            CreateNewEnemy();
        }
    }

    void InitializeEnemies()
    {
        foreach (var enemy in activeEnemies)
        {
            if (enemy != null) Destroy(enemy);
        }
        activeEnemies.Clear();

        for (int i = 0; i < maxEnemies; i++)
        {
            CreateNewEnemy();
        }
    }

    public void CreateNewEnemy()
    {
        if (enemyPrefab == null || mainCamera == null) return;

        float screenAspect = (float)Screen.width / Screen.height;
        float cameraHeight = mainCamera.orthographicSize * 2;
        Bounds cameraBounds = new Bounds(mainCamera.transform.position, new Vector3(cameraHeight * screenAspect, cameraHeight, 0));

        Vector3 AdjustedSize = cameraBounds.size * 0.9f;
        Bounds AdjustedBound = new Bounds(cameraBounds.center, AdjustedSize);

        Vector2 CreatePosition = new Vector2(Random.Range(AdjustedBound.min.x, AdjustedBound.max.x), Random.Range(AdjustedBound.min.y, AdjustedBound.max.y));

        GameObject newEnemy = Instantiate(enemyPrefab, CreatePosition, Quaternion.identity);
        activeEnemies.Add(newEnemy);

        GameStateManager.Instance.IncrementEnemiesCreated();
    }

    public void EnemyDestroyed(GameObject enemy)
    {
        if (activeEnemies.Contains(enemy))
        {
            activeEnemies.Remove(enemy);
        }

        CreateNewEnemy();
    }
}