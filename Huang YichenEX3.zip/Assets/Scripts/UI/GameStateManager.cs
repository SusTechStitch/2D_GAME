using UnityEngine;

public class GameStateManager : MonoBehaviour
{
    public static GameStateManager Instance { get; private set; }

    public int PlaneCollisions { get; private set; }
    public int EggsFired { get; private set; }
    public int EnemiesDestroyed { get; private set; }
    public int EnemiesNumber { get; private set; }
    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            Instance = this;
        }
    }

    public void IncrementPlaneCollisions()
    {
        PlaneCollisions++;
        UpdateUI();
    }

    public void IncrementEggsFired()
    {
        EggsFired++;
        UpdateUI();
    }
    public void IncrementEggsDestroyed()
    {
        EggsFired--;
        UpdateUI();
    }
    public void IncrementEnemiesDestroyed()
    {
        EnemiesDestroyed++;
        EnemiesNumber--;
        UpdateUI();
    }

    public void IncrementEnemiesCreated()
    {
        EnemiesNumber++;
        UpdateUI();
    }

    public void ResetStats()
    {
        PlaneCollisions = 0;
        EggsFired = 0;
        EnemiesDestroyed = 0;
        UpdateUI();
    }

    private void UpdateUI()
    {
        if (StatsDisplayUI.Instance != null)
        {
            StatsDisplayUI.Instance.UpdateStatsDisplay();
        }
    }
}