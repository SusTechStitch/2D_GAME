using UnityEngine;
using TMPro;

public class StatsDisplayUI : MonoBehaviour
{
    public static StatsDisplayUI Instance { get; private set; }

    [Header("UIԪ��")]
    public TMP_Text planeCollisionsText;
    public TMP_Text eggsFiredText;
    public TMP_Text enemiesDestroyedText;
    public TMP_Text EnemyNumber;
    public TMP_Text ControlMode;
    public TMP_Text QuitText;
    public TMP_Text WayPointMode;

    private bool isKeyboardMode = false;
    private bool isRandom = false;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            Instance = this;
        }
    }

    void Start()
    {
        UpdateStatsDisplay();
    }

    void Update()
    {
        CheckInputMode();
        UpdateStatsDisplay();
    }

    public void UpdateStatsDisplay()
    {
        if (GameStateManager.Instance == null) return;

        UpdateText(planeCollisionsText, "TouchedEnemy: ", GameStateManager.Instance.PlaneCollisions);
        UpdateText(eggsFiredText, "EGG:Onscreen ", GameStateManager.Instance.EggsFired);
        UpdateText(enemiesDestroyedText, "Destroyed: ", GameStateManager.Instance.EnemiesDestroyed);
        UpdateText(EnemyNumber, "ENEMY:Count: ", GameStateManager.Instance.EnemiesNumber);

        ControlMode.text = isKeyboardMode ? "Hero:Drive(Key)" : "Hero:Drive(Mouse)";
        QuitText.text = "Press Q to Quit the application";
        WayPointMode.text = isRandom ? "WayPoints(Random)" : "WayPoint(Sequence)";
    }

    private void UpdateText(TMP_Text textElement, string prefix, int value)
    {
        if (textElement != null)
        {
            textElement.text = $"{prefix}{value}";
        }
    }

    public void CheckInputMode()
    {
        if (Input.GetKeyDown(KeyCode.M))
        {
            isKeyboardMode = !isKeyboardMode;
        }

        if (Input.GetKeyDown(KeyCode.J))
        {
            isRandom = !isRandom;
        }
    }

}