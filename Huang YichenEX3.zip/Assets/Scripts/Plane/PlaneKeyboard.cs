using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.RuleTile.TilingRuleOutput;
using UnityEngine.EventSystems;
using UnityEngine.UIElements;

public class PlaneKeyboard : PlaneState
{
    public float GoSpeed;
    public float acceleration = 50f;    
    public float deceleration = 50f;
    private Quaternion initialRotation; 
    public PlaneKeyboard(Plane _plane, PlaneStateMachine _statemachine, string _animeboolname) : base(_plane, _statemachine, _animeboolname)
    {
        initialRotation = plane.transform.rotation;
    }

    public override void Enter()
    {
        base.Enter();
        GoSpeed = plane.movespeed;
    }

    public override void Exit()
    {
        base.Exit();
        plane.transform.rotation = initialRotation;
    }

    public override void Update()
    {
        base.Update();

        if (xInput != 0)
        {
            plane.transform.Rotate(0, 0, plane.rotatespeed * xInput * -1 * Time.deltaTime);
        }

        bool isAccelerating = Input.GetKey(KeyCode.W);

        bool isDecelerating = Input.GetKey(KeyCode.S);


        if (isAccelerating)
        {
            GoSpeed += acceleration * Time.deltaTime;
        }
        else if (isDecelerating)
        {
            GoSpeed -= deceleration * Time.deltaTime;
        }

        Vector2 moveDirection = plane.transform.up;
        Vector2 movement = moveDirection * GoSpeed * Time.deltaTime;

        plane.transform.position += new Vector3(movement.x, movement.y, 0);

        if (Input.GetKeyDown(KeyCode.M))
        {
            statemachine.ChangeState(plane.cursor);
        }
    }


}
