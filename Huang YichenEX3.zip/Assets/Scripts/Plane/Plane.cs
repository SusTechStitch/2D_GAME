using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using static UnityEngine.EventSystems.EventTrigger;



public class Plane : Entity
{

    [Header("Move Info")]
    public float movespeed = 12f;
    public float rotatespeed = .2f;


    public SkillManager skill { get; private set; }
    public GameObject egg;//{ get; private set; }


    #region  States
    public PlaneStateMachine statemachine { get; private set; }
    public PlaneCursor cursor { get; private set; }
    public PlaneKeyboard Keyboard { get; private set; }
    #endregion

    protected override void Awake()
    {
        base.Awake();

        statemachine = new PlaneStateMachine();

        Keyboard = new PlaneKeyboard(this, statemachine, "isKey");

        cursor = new PlaneCursor(this, statemachine, "isCur");

        if (PlaneManager.Instance != null)
        {
            PlaneManager.Instance.RegisterPlane(this);
        }
    }

    protected override void Start()
    {
        base.Start();

        statemachine.Initialize(cursor);
    }

    protected override void Update()
    {
        base.Update();

        statemachine.currentstate.Update();

        HandleQuitInput();
    }


    private void HandleQuitInput()
    {
        if (Input.GetKeyDown(KeyCode.Q))
        {
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }
    }

}