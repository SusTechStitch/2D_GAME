using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.RuleTile.TilingRuleOutput;

public class PlaneCursor : PlaneState
{
    public PlaneCursor(Plane _plane, PlaneStateMachine _statemachine, string _animeboolname) : base(_plane, _statemachine, _animeboolname)
    {
    }

    public override void Enter()
    {
        base.Enter();
    }

    public override void Exit()
    {
        base.Exit();
    }

    public override void Update()
    {
        base.Update();

        Vector3 mousePos = Input.mousePosition;

        mousePos = Camera.main.ScreenToWorldPoint(mousePos);
        plane.transform.position = new Vector3(mousePos.x, mousePos.y, 0);

        if (Input.GetKeyDown(KeyCode.M))
        {
            statemachine.ChangeState(plane.Keyboard);
        }
    }
}
