using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaneState
{
    protected PlaneStateMachine statemachine;
    public Plane plane;

    protected Rigidbody2D rb;

    protected float xInput;
    protected float yInput;

    private string animeboolname;
    protected float statetimer;

    public PlaneState(Plane _plane, PlaneStateMachine _statemachine, string _animeboolname)
    {
        this.plane = _plane;
        this.statemachine = _statemachine;
        this.animeboolname = _animeboolname;
    }

    public virtual void Enter()
    {
        plane.anime.SetBool(animeboolname, true);
        rb = plane.rb;
    }
    public virtual void Update()
    {
        statetimer -= Time.deltaTime;

        xInput = Input.GetAxisRaw("Horizontal");
        yInput = Input.GetAxisRaw("Vertical");

    }
    public virtual void Exit()
    {
        plane.anime.SetBool(animeboolname, false);
    }

}
