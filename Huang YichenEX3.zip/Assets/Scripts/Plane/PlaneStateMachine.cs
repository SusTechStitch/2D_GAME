using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Playables;

public class PlaneStateMachine
{

    public PlaneState currentstate { get; private set; }

    public void Initialize(PlaneState _startstate)
    {
        currentstate = _startstate;
        currentstate.Enter();
    }

    public void ChangeState(PlaneState _newstate)
    {
        currentstate.Exit();
        currentstate = _newstate;
        currentstate.Enter();
    }
}
