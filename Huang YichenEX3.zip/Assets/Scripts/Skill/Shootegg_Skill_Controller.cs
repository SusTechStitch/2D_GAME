using UnityEngine;

public class Shootegg_Skill_Controller : MonoBehaviour
{
    [Header("Settings")]
    [SerializeField] private float moveSpeed;

    private Rigidbody2D rb;
    private Vector2 moveDirection;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        if (IsOutOfScreen())
        {
            DestroyEgg();
        }
    }

    public void SetupEgg(Vector2 direction, Quaternion rotation)
    {
        moveDirection = direction.normalized;
        transform.rotation = rotation;
        rb.velocity = moveDirection * moveSpeed;
    }

    private bool IsOutOfScreen()
    {
        Vector3 screenPos = Camera.main.WorldToViewportPoint(transform.position);
        return screenPos.x < -0.1f || screenPos.x > 1.1f || screenPos.y < -0.1f || screenPos.y > 1.1f;
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Enemy"))
        {
            Enemy enemy = collision.GetComponent<Enemy>();
            if (enemy != null)
            {
                enemy.TakeHit();
            }
            DestroyEgg();
        }

        if (collision.CompareTag("WayPoint"))
        {
            WayPoint wayPoint = collision.GetComponent<WayPoint>();
            if (wayPoint != null)
            {
                wayPoint.TakeHit();
            }
            DestroyEgg();
        }
    }

    public void DestroyEgg()
    {
        Destroy(gameObject);
        GameStateManager.Instance.IncrementEggsDestroyed();
    }
}