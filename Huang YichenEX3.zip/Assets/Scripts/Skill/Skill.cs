using UnityEngine;

public class Skill : MonoBehaviour
{
    [SerializeField] protected float cooldown = 0.2f;
    protected float cooldownTimer;
    protected Plane plane;

    protected virtual void Start()
    {
        plane = PlaneManager.Instance.plane;
        cooldownTimer = 0;
    }

    protected virtual void Update()
    {
        if (cooldownTimer > 0)
        {
            cooldownTimer -= Time.deltaTime;
        }
    }

    public virtual bool CanUseSkill()
    {
        if (cooldownTimer <= 0)
        {
            UseSkill();
            cooldownTimer = cooldown;
            return true;
        }
        return false;
    }

    public virtual void UseSkill()
    {
        
    }
}