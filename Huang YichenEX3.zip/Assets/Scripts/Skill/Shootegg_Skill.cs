using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; // ����UI�����ռ�

public class Shootegg_Skill : Skill
{
    [Header("Skill Settings")]
    [SerializeField] private GameObject eggPrefab;
    [SerializeField] private float ShootOffSet = 0.5f;
    [SerializeField] private float minShootInterval = 0.2f;

    [Header("Cooldown UI")]
    [SerializeField] private Image cooldownBarLeft; // ��ȴ��UI
    [SerializeField] private Image cooldownBarRight; // ��ȴ��UI
    [SerializeField] private GameObject cooldownContainer; // ������ȴ��������
    [SerializeField] private Color readyColor = Color.green; // ׼������ʱ����ɫ
    [SerializeField] private Color cooldownColor = Color.red; // ��ȴ�е���ɫ

    private float lastShootTime;
    private List<Shootegg_Skill_Controller> activeEggs = new List<Shootegg_Skill_Controller>();

    protected override void Start()
    {
        base.Start();
        InitializeCooldownUI();
    }

    protected override void Update()
    {
        base.Update();

        UpdateCooldownUI();

        if (Input.GetKey(KeyCode.Space) && CanShoot())
        {
            CreateEgg();
            lastShootTime = Time.time;
        }

        CleanupDestroyedEggs();
    }

    private void InitializeCooldownUI()
    {
        if (cooldownBarLeft != null || cooldownBarRight != null)
        {
            cooldownBarLeft.type = Image.Type.Filled;
            cooldownBarLeft.fillMethod = Image.FillMethod.Horizontal;
            cooldownBarLeft.fillAmount = 1f;
            cooldownBarLeft.color = readyColor;

            cooldownBarRight.type = Image.Type.Filled;
            cooldownBarRight.fillMethod = Image.FillMethod.Horizontal;
            cooldownBarRight.fillAmount = 1f;
            cooldownBarRight.color = readyColor;
        }

        if (cooldownContainer != null)
        {
            cooldownContainer.SetActive(false); // ��ʼʱ����
        }
    }

    // ������ȴUI
    private void UpdateCooldownUI()
    {
        if (cooldownBarLeft == null || cooldownBarRight == null || cooldownContainer == null) return;

        // ������ȴ���� (0-1)
        float cooldownProgress = Mathf.Clamp01((Time.time - lastShootTime) / minShootInterval);

        // �Ƿ�����ȴ��
        bool isCooldown = cooldownProgress < 1f;

        // ��ʾ/������ȴ����
        cooldownContainer.SetActive(isCooldown);

        if (isCooldown)
        {
            // ������ȴ������� (��ȴ���ʱΪ0���տ�ʼ��ȴʱΪ1)
            float fillAmount = 1f - cooldownProgress;
            cooldownBarLeft.fillAmount = fillAmount;
            cooldownBarRight.fillAmount = fillAmount;

            // ������ȴ���Ȳ�ֵ��ɫ
            cooldownBarLeft.color = Color.Lerp(readyColor, cooldownColor, fillAmount);
            cooldownBarRight.color = Color.Lerp(readyColor, cooldownColor, fillAmount);
        }
    }

    private bool CanShoot()
    {
        return Time.time - lastShootTime >= minShootInterval;
    }

    private void CleanupDestroyedEggs()
    {
        for (int i = activeEggs.Count - 1; i >= 0; i--)
        {
            if (activeEggs[i] == null)
            {
                activeEggs.RemoveAt(i);
            }
        }
    }

    public override void UseSkill()
    {
        // ʹ�ü��ܵ��߼�
    }

    private void CreateEgg()
    {
        if (plane == null) return;

        Vector2 ShootPosition = (Vector2)plane.transform.position + (Vector2)plane.transform.up * ShootOffSet;

        GameObject newEgg = Instantiate(eggPrefab, ShootPosition, plane.transform.rotation);
        Shootegg_Skill_Controller eggController = newEgg.GetComponent<Shootegg_Skill_Controller>();

        if (eggController != null)
        {
            eggController.SetupEgg(plane.transform.up, plane.transform.rotation);
            activeEggs.Add(eggController);
        }

        GameStateManager.Instance.IncrementEggsFired();
    }

    public int GetActiveEggCount()
    {
        return activeEggs.Count;
    }

    public void ClearAllEggs()
    {
        foreach (var egg in activeEggs)
        {
            if (egg != null)
            {
                Destroy(egg.gameObject);
            }
        }
        activeEggs.Clear();
    }
}