using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkeletonStunnedState : EnemyState
{

    private Enemy_Skeleton enemy; 

    public SkeletonStunnedState(Enemy _enemyBase, EnemyStateMachine _StateMachine, string _AnimeboolName, Enemy_Skeleton _enemy) : base(_enemyBase, _StateMachine, _AnimeboolName)
    {
        this.enemy = _enemy;
    }

    public override void Enter()
    {
        base.Enter();

        enemy.fx.InvokeRepeating("RedColorBlink" , 0 , .1f);

        StateTimer = enemy.StunDuration;

        rb.velocity = new Vector2(-enemy.facingDir * enemy.StunDirection.x, enemy.StunDirection.y);

    }

    public override void Exit()
    {
        base.Exit();

        enemy.fx.Invoke("CancelRedBlink" , 0 );
    }

    public override void Update()
    {
        base.Update();

        if (StateTimer < 0)
        {
            StateMachine.ChangeState(enemy.idolState);
        }

    }
}
