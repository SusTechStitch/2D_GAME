using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyState 
{
    protected EnemyStateMachine StateMachine;

    protected Enemy enemyBase;

    protected Rigidbody2D rb;


    protected bool triggercalled;
    private string AnimboolName;
    protected float StateTimer; 

    public EnemyState(Enemy _enemyBase , EnemyStateMachine _StateMachine , string _AnimeboolName)
    {
        this.enemyBase = _enemyBase;
        this.StateMachine = _StateMachine;
        this.AnimboolName = _AnimeboolName; 
    }

    public virtual void Update()
    {
        StateTimer -= Time.deltaTime; 
    }

    public virtual void Enter()
    {
        triggercalled = false;
        rb = enemyBase.rb;


        enemyBase.anime.SetBool(AnimboolName, true); 
    }

    public virtual void Exit()
    {
        enemyBase.anime.SetBool(AnimboolName, false);
    }


    public virtual void AnimationFinishTrigger()
    {
        triggercalled = true; 
    }

}

