using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPrimaryAttack : PlayerState
{
    private int combocounter;

    private float lasttimeAttacked;
    private float comboWindow = 2; 



    public PlayerPrimaryAttack(Player _player, PlayerStateMachine _statemachine, string _animeboolname) : base(_player, _statemachine, _animeboolname)
    {}

    public override void Enter()
    {
        base.Enter();

        xInput = 0;

        if (combocounter > 2 || Time.time >= lasttimeAttacked + comboWindow ) 
        {
            combocounter = 0; 
        }
        
        player.anime.SetInteger("combocounter", combocounter);

        #region Choose attack Direction
        float attackDir = player.facingDir; 
        if ( xInput != 0 )
        {
            attackDir = xInput; 
        }
        #endregion

        player.SetVelocity(player.AttackMovement[combocounter].x * attackDir, player.AttackMovement[combocounter].y); 


        statetimer = .1f; 
    }

    public override void Exit()
    {
        base.Exit();

        player.StartCoroutine("BusyFor", .15f);

        combocounter++;
        
        lasttimeAttacked = Time.time;
    }

    public override void Update()
    {
        base.Update();
        if (statetimer < 0 )
        {
            player.SetZeroVelocity(); 
        }


        if(triggercalled)
        {
            statemachine.ChangeState(player.idolstate); 
        }
    }
}
