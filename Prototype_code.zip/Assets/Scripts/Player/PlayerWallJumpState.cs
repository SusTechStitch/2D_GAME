using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerWallJumpState : PlayerState
{
    public PlayerWallJumpState(Player _player, PlayerStateMachine _statemachine, string _animeboolname) : base(_player, _statemachine, _animeboolname)
    {
    }

    public override void Enter()
    {
        base.Enter();

        statetimer = 0.4f;
        player.SetVelocity(5 * -player.facingDir, player.jumpforce); 
    }

    public override void Exit()
    {
        base.Exit();
    }

    public override void Update()
    {
        base.Update();
        if (statetimer < 0)
        {
            statemachine.ChangeState(player.AirState);
        }
        if (player.isGroundedDetected())
        {
            statemachine.ChangeState(player.idolstate); 
        }
    }
}
