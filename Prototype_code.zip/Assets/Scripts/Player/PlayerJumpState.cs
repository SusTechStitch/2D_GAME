using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerJumpState : PlayerState
{
    public PlayerJumpState(Player _player, PlayerStateMachine _statemachine, string _animeboolname) : base(_player, _statemachine, _animeboolname)
    {
    }

    public override void Enter()
    {
        base.Enter();

        rb.velocity = new Vector2(rb.velocity.x, player.jumpforce);
    }

    public override void Exit()
    {
        base.Exit();
    }

    public override void Update()
    {
        base.Update();

        if (rb.velocity.y < 0 )
        {
            statemachine.ChangeState(player.AirState); 
        }

        if (xInput != 0)
        {
            player.SetVelocity(player.movespeed * xInput * 0.8f, rb.velocity.y);
        }

    }
}
