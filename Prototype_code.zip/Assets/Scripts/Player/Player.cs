using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

public class Player : Entity
{
    public bool isBusy { get; private set; }
    [Header("Attack Details")]
    public Vector2[] AttackMovement;
    public float counterAttackDuration = .2f;


    [Header("Move Info")]
    public float movespeed = 12f;
    public float jumpforce;
    public float SwordReturnImpact;

    [Header("Dash Info")]
    
    public float dashSpeed;
    public float dashDuration;
    public float dashDir { get; private set; }


    public SkillManager skill { get; private set; }
    public GameObject sword { get; private set; }



    #region  States
    public PlayerStateMachine statemachine { get; private set; }
    public PlayerIdolState idolstate { get; private set; }
    public PlayerMoveState moveState { get; private set; }
    public PlayerJumpState JumpState { get; private set; }
    public PlayerAirState AirState { get; private set; }
    public PlayerWallSlideState WallSlideState { get; private set; }
    public PlayerWallJumpState WallJumpState { get; private set; }
    public PlayerDashState DashState { get; private set;  }
    public PlayerPrimaryAttack PrimaryAttack { get; private set;  }
    public PlayerCounterAttackState CounterAttack { get; private set; }
    public PlayerAimSwordState AimSword { get; private set; }

    public PlayerCatchSwordState CatchSword { get; private set; }



    #endregion

    protected override void Awake()
    {
        base.Awake(); 

        statemachine = new PlayerStateMachine();

        idolstate = new PlayerIdolState(this, statemachine, "isIdol");

        moveState = new PlayerMoveState(this, statemachine, "isMove");

        JumpState = new PlayerJumpState(this, statemachine, "Jump");

        AirState = new PlayerAirState(this, statemachine, "Jump");

        WallSlideState = new PlayerWallSlideState(this, statemachine, "WallSlide");

        WallJumpState = new PlayerWallJumpState(this, statemachine, "Jump");  

        DashState = new PlayerDashState(this, statemachine, "Dash");

        PrimaryAttack = new PlayerPrimaryAttack(this, statemachine, "Attack");

        CounterAttack = new PlayerCounterAttackState(this, statemachine, "CounterAttack");

        AimSword = new PlayerAimSwordState(this, statemachine, "AimSword");

        CatchSword = new PlayerCatchSwordState(this, statemachine, "CatchSword");


    }

    protected override void Start()
    {
        base.Start();


        skill = SkillManager.instance;


        statemachine.Initialize(idolstate); 

    }

    protected override void Update()
    {
        base.Update(); 

        statemachine.currentstate.Update();

        CheckforDashInput(); 
    }

    public void AssignNewSword( GameObject _newSword )
    {
        sword = _newSword;
    }

    public void CatchTheSword()
    {
        statemachine.ChangeState(CatchSword);
        Destroy(sword);
    }

    public IEnumerator BusyFor ( float _seconds )
    {
        isBusy = true;
        yield return new WaitForSeconds(_seconds);
        isBusy = false; 
    }


    public void AnimationTrigger() => statemachine.currentstate.AnimationFinishTrigger(); 
    
    private void CheckforDashInput()
    {
        if (isWallDetected())
        {
            return; 
        }
        

        if (Input.GetKeyDown(KeyCode.LeftShift) && SkillManager.instance.dash.CanUseSkill() )
        {
            

            dashDir = Input.GetAxisRaw("Horizontal"); 
            if ( dashDir == 0 )
            {
                dashDir = facingDir; 
            }

            statemachine.ChangeState(DashState); 
        }
    }

    


    

    

}


