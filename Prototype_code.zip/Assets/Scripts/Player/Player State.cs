using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerState
{
    protected PlayerStateMachine statemachine;
    protected Player player;

    protected Rigidbody2D rb; 

    protected float xInput;
    protected float yInput; 

    private string animeboolname;

    protected float statetimer;
    protected bool triggercalled; 

    public PlayerState(Player _player, PlayerStateMachine _statemachine, string _animeboolname)
    {
        this.player = _player;
        this.statemachine = _statemachine;
        this.animeboolname = _animeboolname;
    }

    public virtual void Enter() 
    {
        player.anime.SetBool(animeboolname, true);
        rb = player.rb;
        triggercalled = false; 
    }
    public virtual void Update() 
    {
        statetimer -= Time.deltaTime; 

        xInput = Input.GetAxisRaw("Horizontal");
        yInput = Input.GetAxisRaw("Vertical"); 

        player.anime.SetFloat("yVelocity", rb.velocity.y);
    }
    public virtual void Exit() 
    {
        player.anime.SetBool(animeboolname, false);
    }

    public virtual void AnimationFinishTrigger()
    {
        triggercalled = true; 
    }

}
