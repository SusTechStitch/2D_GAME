using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Clone_Skill : Skill
{

    [Header("Clone Info")]
    [SerializeField] private GameObject cloneprefab;
    [SerializeField] private float cloneDurarion;
    [Space]
    [SerializeField] private bool canAttack; 


    public void CreateClone(Transform _clonePostion)
    {
        GameObject newClone = Instantiate(cloneprefab);



        newClone.GetComponent<Clone_Skill_Controller>().SetUpClone(_clonePostion , cloneDurarion , canAttack);
    }


}
