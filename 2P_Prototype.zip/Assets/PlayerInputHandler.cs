using UnityEngine;

public abstract class PlayerInputHandler : MonoBehaviour
{
    public abstract float GetHorizontalRaw();
    public abstract float GetVerticalRaw();
    public abstract bool JumpPressed();
    public abstract bool DashPressed();
    public abstract bool PrimaryAttackPressed();
}