using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkeletonIdolState : SkeletonGroundedState
{
    public SkeletonIdolState(Enemy _enemyBase, EnemyStateMachine _StateMachine, string _AnimeboolName, Enemy_Skeleton _enemy) : base(_enemyBase, _StateMachine, _AnimeboolName, _enemy)
    {
    }

    public override void Enter()
    {
        base.Enter();

        StateTimer = enemy.idolTime; 
    }

    public override void Exit()
    {
        base.Exit();
    }

    public override void Update()
    {
        base.Update();

        if ( StateTimer < 0 )
        {
            StateMachine.ChangeState(enemy.moveState); 
        }


    }
}
