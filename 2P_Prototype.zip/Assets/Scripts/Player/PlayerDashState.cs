using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerDashState : PlayerState
{
    public PlayerDashState(Player _player, PlayerStateMachine _statemachine, string _animeboolname) : base(_player, _statemachine, _animeboolname)
    {
    }

    public override void Enter()
    {
        base.Enter();

        player.skill.clone.CreateClone(player.anime.transform);
        statetimer = player.dashDuration;  

    }

    public override void Exit()
    {
        base.Exit();
        player.SetVelocity(0, rb.velocity.y); 
    }

    public override void Update()
    {
        base.Update();

        if (!player.isGroundedDetected() && player.isWallDetected())
        {
            statemachine.ChangeState(player.WallSlideState); 
        }

        player.SetVelocity(player.dashSpeed * player.dashDir, 0); 

        if (statetimer < 0 )
        {
            statemachine.ChangeState(player.idolstate); 
        }

    }
}
