using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerGroundedState : PlayerState
{
    public PlayerGroundedState(Player _player, PlayerStateMachine _statemachine, string _animeboolname) : base(_player, _statemachine, _animeboolname)
    {
    }

    public override void Enter()
    {
        base.Enter();
    }

    public override void Exit()
    {
        base.Exit();
    }

    public override void Update()
    {
        base.Update();

        if (Input.GetKeyDown(KeyCode.Mouse1) && HasNoSword() )
        {
            statemachine.ChangeState(player.AimSword);
        }


        if (Input.GetKeyDown(KeyCode.Q))
        {
            statemachine.ChangeState(player.CounterAttack);
        }


        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            statemachine.ChangeState(player.PrimaryAttack); 
        }


        if ( !player.isGroundedDetected())
        {
            statemachine.ChangeState(player.AirState); 
        }


        if ( player.InputHandler.JumpPressed() && player.isGroundedDetected() ) 
        {
            statemachine.ChangeState(player.JumpState); 
        }
    }

    private bool HasNoSword()
    {
        if (!player.sword)
        {
            return true; 
        }

        player.sword.GetComponent<Sword_Skill_Controller>().ReturnSword();

        return false; 
    }

}
