using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAirState : PlayerState
{
    public PlayerAirState(Player _player, PlayerStateMachine _statemachine, string _animeboolname) : base(_player, _statemachine, _animeboolname)
    {
    }

    public override void Enter()
    {
        base.Enter();
    }

    public override void Exit()
    {
        base.Exit();
    }

    public override void Update()
    {
        base.Update();

        if (player.isGroundedDetected())
        {
            statemachine.ChangeState(player.idolstate); 
        }


        if (xInput != 0 )
        {
            player.SetVelocity(player.movespeed * 0.8f * xInput, rb.velocity.y); 
        }

        if (player.isWallDetected())
        {
            statemachine.ChangeState(player.WallSlideState);
        }

    }
}
