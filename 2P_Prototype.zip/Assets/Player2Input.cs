using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player2Input : PlayerInputHandler
{
    public override float GetHorizontalRaw() => Input.GetAxisRaw("Horizontal_P2");
    public override float GetVerticalRaw() => Input.GetAxis("Vertical_P2");
    public override bool JumpPressed() => Input.GetKey(KeyCode.UpArrow);
    public override bool DashPressed() => Input.GetKeyDown(KeyCode.RightControl);
    public override bool PrimaryAttackPressed() => Input.GetKeyDown(KeyCode.RightShift);
}
