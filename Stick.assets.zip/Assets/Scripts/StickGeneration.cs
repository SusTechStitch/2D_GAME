using UnityEngine;
using UnityEngine.EventSystems;
using System.Collections;

public class StickSpawner : MonoBehaviour
{
    [Header("ľ������")]
    public GameObject stickPrefab; // ����Assets/prefabs/StickԤ����
    public LayerMask groundLayer;   // ����Ground�������ڵ�Layer
    public float stickWidth = 0.2f; // ľ������

    [Header("��������")]
    public float minLength = 1f;   // ��С����
    public float maxLength = 10f;  // ��󳤶�
    public bool active = true;

    private Camera mainCamera;

    void Start()
    {
        mainCamera = Camera.main;
    }

    void Update()
    {
        if (!active)
            return;
        if (Input.GetMouseButtonDown(0))
        {

            StartCoroutine(SpawnStick());
        }
    }

    IEnumerator SpawnStick()
    {
        // ��ȡ���λ��
        Vector3 mousePosition = Input.mousePosition;
        Vector3 worldMousePosition = mainCamera.ScreenToWorldPoint(
            new Vector3(mousePosition.x, mousePosition.y, -mainCamera.transform.position.z)
        );

        // ���߼�����
        RaycastHit2D hit = Physics2D.Raycast(
            worldMousePosition,
            Vector2.down,
            Mathf.Infinity,
            groundLayer
        );

        if (!hit.collider)
        {
            Debug.LogWarning("δ��⵽����");
            yield break;
        }

        Vector3 groundPosition = hit.point;

        // ����ľ������
        float stickLength = Mathf.Clamp(
            worldMousePosition.y - groundPosition.y,
            minLength,
            maxLength
        );

        // ����ľ��
        Vector3 stickPosition = new Vector3(
            worldMousePosition.x,
            groundPosition.y + stickLength / 2,
            0
        );

        GameObject newStick = Instantiate(stickPrefab, stickPosition, Quaternion.identity);

        // ����ľ���ߴ�
        newStick.transform.localScale = new Vector3(
            stickWidth,
            stickLength,
            1
        );

        // ȷ����StickController���
        StickController controller = newStick.GetComponent<StickController>();
        if (!controller) controller = newStick.AddComponent<StickController>();

        // ������ײ��
        BoxCollider2D collider = newStick.GetComponent<BoxCollider2D>();
        if (!collider) collider = newStick.AddComponent<BoxCollider2D>();

        // ���ø���
        Rigidbody2D rb = newStick.GetComponent<Rigidbody2D>();
        if (rb)
        {
            rb.bodyType = RigidbodyType2D.Kinematic;
        }
        else
        {
            rb = newStick.AddComponent<Rigidbody2D>();
           rb.bodyType = RigidbodyType2D.Kinematic;
        }

        // ��ʼ��������
        controller.Initialize();

        yield return null;
    }
}