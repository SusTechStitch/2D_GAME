using System.Collections;
using UnityEngine;

public class StickController : MonoBehaviour
{
    [Header("�ƶ�����")]
    public float moveDistance = 5f;
    public float moveTime = 0.5f;

    [Header("��ת����")]
    public float rotationAngle = 90f; // ��ֵΪ˳ʱ��
    public float rotationTime = 0.5f;

    // ˽�б���
    private bool isAnimating = false;
    private Collider2D objectCollider;
    private Vector3 pivotLocalOffset;

    // �������������ⲿ��ʼ������
    public void Initialize()
    {
        objectCollider = GetComponent<Collider2D>();
        CalculatePivotOffset();
    }

    // ����֧��
    void CalculatePivotOffset()
    {
        if (!objectCollider) return;

        pivotLocalOffset = new Vector3(0, -0.5f, 0);

        Debug.Log($"֧��ƫ�Ƽ������: {pivotLocalOffset}");
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log("hits");
        if (isAnimating || !collision.gameObject.CompareTag("Steam")) return;
        if (collision.contacts.Length == 0) return;

        // ��ײ��ת��Ϊ�ֲ�����
        Vector2 localCollisionPoint = transform.InverseTransformPoint(collision.contacts[0].point);

        // ������ײ��߶Ⱦ�����Ϊ
        bool shouldRotate = localCollisionPoint.y > 0;

        int direction = localCollisionPoint.x < 0 ? 1 : -1;
        if (shouldRotate)
        {
            StartCoroutine(Rotate(direction));
        }
        else
        {
            StartCoroutine(Move(direction));
        }
    }

    IEnumerator Move(int direction)
    {
        isAnimating = true;

        Vector2 startPos = transform.position;
        Vector2 moveDirection = transform.right;
        Vector2 endPos = startPos + direction*(moveDirection * moveDistance);

        float elapsed = 0f;
        while (elapsed < moveTime)
        {
            float t = Mathf.SmoothStep(0, 1, elapsed / moveTime);
            transform.position = Vector2.Lerp(startPos, endPos, t);
            elapsed += Time.deltaTime;
            yield return null;
        }

        transform.position = endPos;
        isAnimating = false;
    }

    IEnumerator Rotate(int direction)
    {
        isAnimating = true;

        // ��ȡ��ת֧�㣨�ڶ�����ʼʱ�̶���
        Vector3 pivotPoint = GetStablePivotPoint();

        // ��¼��ʼ״̬
        Vector3 startPosition = transform.position;
        Quaternion startRotation = transform.rotation;
        Quaternion targetRotation;
        // ����Ŀ����ת��˳ʱ�룩
        if(direction > 0)
        targetRotation = startRotation * Quaternion.Euler(0, 0, -rotationAngle);
        else
        targetRotation = startRotation * Quaternion.Euler(0, 0, rotationAngle);

        float elapsed = 0f;
        while (elapsed < rotationTime)
        {
            float t = Mathf.SmoothStep(0, 1, elapsed / rotationTime);

            // ���㵱ǰ��ת
            Quaternion currentRotation = Quaternion.Slerp(startRotation, targetRotation, t);

            // Χ��֧����ת
            RotateAroundPivot(pivotPoint, currentRotation);

            elapsed += Time.deltaTime;
            yield return null;
        }

        // ȷ��������ת׼ȷ
        RotateAroundPivot(pivotPoint, targetRotation);

        isAnimating = false;
    }

    // Χ��֧����ת�ĺ��ķ���
    void RotateAroundPivot(Vector3 pivot, Quaternion rotation)
    {
        // �����֧�㵽���������
        Vector3 dir = transform.position - pivot;

        // ��ת�������
        Vector3 rotatedDir = rotation * Quaternion.Inverse(transform.rotation) * dir;

        // ����λ�ú���ת
        transform.position = pivot + rotatedDir;
        transform.rotation = rotation;
    }

    // ��ȡ�ȶ�֧��
    Vector3 GetStablePivotPoint()
    {
        return transform.TransformPoint(pivotLocalOffset);
    }

}