using UnityEngine;

public class ElementCarrier : MonoBehaviour
{
    public enum ElementType { Fire, Wood, Water }
    public ElementType elementType;
}
