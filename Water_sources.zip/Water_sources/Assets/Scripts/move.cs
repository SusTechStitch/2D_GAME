using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerController : MonoBehaviour
{
    [Header("�����ƶ�����")]
    public float moveSpeed = 5f;
    public float jumpForce = 8f;
    public LayerMask groundLayer;

    [Header("ˮ���ƶ�����")]
    public float swimSpeed = 4f;

    private Rigidbody2D rb;
    private bool isGrounded;
    private bool isInWater = false;
    private float normalGravity;

    private ElementCarrier elementCarrier;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        normalGravity = rb.gravityScale;
        elementCarrier = GetComponent<ElementCarrier>();
    }

    void Update()
    {
        if (isInWater && elementCarrier != null && elementCarrier.elementType == ElementCarrier.ElementType.Water)
        {
            Swim();
        }
        else
        {
            Move();
            Jump();
        }
    }

    void Move()
    {
        isGrounded = Physics2D.Raycast(transform.position, Vector2.down, 0.6f, groundLayer);

        float inputX = Input.GetAxisRaw("Horizontal"); // A D
        Vector2 velocity = rb.velocity;
        velocity.x = inputX * moveSpeed;
        rb.velocity = velocity;
    }

    void Jump()
    {
        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
        }
    }

    void Swim()
    {
        rb.gravityScale = 0;

        float inputX = Input.GetAxisRaw("Horizontal"); // A D
        float inputY = Input.GetAxisRaw("Vertical");   // W S

        Vector2 swimVelocity = new Vector2(inputX, inputY) * swimSpeed;
        rb.velocity = swimVelocity;
    }

    private void FixedUpdate()
    {
        // �뿪ˮ�غ�ָ���������
        if (!(isInWater && elementCarrier != null && elementCarrier.elementType == ElementCarrier.ElementType.Water))
        {
            rb.gravityScale = normalGravity;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("WaterPool"))
        {
            isInWater = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("WaterPool"))
        {
            isInWater = false;
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawLine(transform.position, transform.position + Vector3.down * 0.6f);
    }
}
