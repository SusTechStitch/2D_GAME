using UnityEngine;

public class PoolZone : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        ElementCarrier carrier = collision.GetComponent<ElementCarrier>();
        if (carrier != null)
        {
            if (carrier.elementType != ElementCarrier.ElementType.Water)
            {
                Debug.Log($"{collision.name} û��ˮ���ԣ���ˮ��û�ˣ�");
                Destroy(collision.gameObject);
            }
            else
            {
                Debug.Log($"{collision.name} ӵ��ˮ���ԣ�����ˮ����Ӿ��");
            }
        }
    }
}
