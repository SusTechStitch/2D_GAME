using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class IceBreaking : MonoBehaviour
{
    public TextMeshProUGUI TipsText;
    public string signText;
    public Collider2D iceCollider; // 碰撞体引用
    private bool isPlayerColliding;

    void Start()
    {
        // 确保初始状态下TipsText是隐藏的
        if (TipsText != null)
            TipsText.gameObject.SetActive(false);

        // 自动获取碰撞体引用
        if (iceCollider == null)
        {
            iceCollider = GetComponent<Collider2D>();
            if (iceCollider == null)
            {
                Debug.LogError("IceBreaking脚本需要一个碰撞体组件！");
            }
            else
            {
                // 设置为非触发器（阻挡玩家）
                iceCollider.isTrigger = false;
            }
        }
    }

    void Update()
    {
        if (isPlayerColliding && TipsText != null)
        {
            TipsText.text = signText;
            TipsText.gameObject.SetActive(true);
            Debug.Log("isclose ice");
        }
        else if (TipsText != null)
        {
            TipsText.gameObject.SetActive(false);
            Debug.Log("notclose ice");
        }
    }

    // 使用非触发器碰撞检测
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            isPlayerColliding = true;
        }
    }

    void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            isPlayerColliding = false;
        }
    }

    void DestroySign()
    {
        Debug.Log("销毁Sign对象");
        
        if (TipsText != null)
            TipsText.gameObject.SetActive(false);
            
        Destroy(gameObject);
    }
}