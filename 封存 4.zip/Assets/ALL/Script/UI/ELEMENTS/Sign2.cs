using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro; // 添加TextMeshPro命名空间

public class Sign2 : MonoBehaviour
{
    public TextMeshProUGUI TipsText; // 直接引用TextMeshProUGUI组件
    public string signText;
    private bool isPlayerInSign;

    void Start()
    {
        // 确保初始状态下TipsText是隐藏的
        if (TipsText != null)
            TipsText.gameObject.SetActive(false);
    }

    void Update()
    {
        if (isPlayerInSign && TipsText != null)
        {
            TipsText.text = signText;
            TipsText.gameObject.SetActive(true);
            Debug.Log("isclose");
            
            // 检查是否按下T键
            if (Input.GetKeyDown(KeyCode.T))
            {
                DestroySign();
            }
        }
        else if (TipsText != null)
        {
            TipsText.gameObject.SetActive(false); // 离开时隐藏TipsText
            Debug.Log("notclose");
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            isPlayerInSign = true;
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            isPlayerInSign = false;
        }
    }

    // 新增：销毁Sign的方法
    void DestroySign()
    {
        Debug.Log("销毁Sign对象");
        
        // 确保UI先隐藏
        if (TipsText != null)
            TipsText.gameObject.SetActive(false);
        
        // 销毁Sign对象
        Destroy(gameObject);
    }
}