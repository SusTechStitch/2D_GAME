using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SignMultiUI : MonoBehaviour
{
    // 8个UI Image数组
    public Image[] uiImages = new Image[8];
    // 主文本UI
    public TextMeshProUGUI tipsText;
    // 新增：3个额外的TextMeshProUGUI
    public TextMeshProUGUI[] additionalTexts = new TextMeshProUGUI[3];
    // 显示的文本内容
    public string signText;
    // 新增：3个额外文本的内容
    public string[] additionalTextsContent = new string[3];
    // 玩家是否在触发范围内
    private bool isPlayerInRange;

    void Start()
    {
        // 初始隐藏所有UI元素
        HideAllUI();
    }

    void Update()
    {
        if (isPlayerInRange)
        {
            // 显示所有UI
            ShowAllUI();
            // 设置文本内容
            if (tipsText != null)
                tipsText.text = signText;
                
            // 新增：设置3个额外文本的内容
            for (int i = 0; i < additionalTexts.Length && i < additionalTextsContent.Length; i++)
            {
                if (additionalTexts[i] != null)
                    additionalTexts[i].text = additionalTextsContent[i];
            }

            Debug.Log("玩家在范围内，显示UI");

            // // 按T键隐藏UI并销毁当前物体（可选）
            // if (Input.GetKeyDown(KeyCode.T))
            // {
            //     HideAllUI();
            //     Destroy(gameObject);
            //     Debug.Log("销毁物体");
            // }
        }
        else
        {
            // 隐藏所有UI
            HideAllUI();
            Debug.Log("玩家不在范围内，隐藏UI");
        }
    }

    // 显示所有UI元素
    private void ShowAllUI()
    {
        // 显示8个Image
        foreach (Image img in uiImages)
        {
            if (img != null)
                img.gameObject.SetActive(true);
        }
        
        // 显示主文本
        if (tipsText != null)
            tipsText.gameObject.SetActive(true);
            
        // 新增：显示3个额外文本
        foreach (TextMeshProUGUI text in additionalTexts)
        {
            if (text != null)
                text.gameObject.SetActive(true);
        }
    }

    // 隐藏所有UI元素
    private void HideAllUI()
    {
        // 隐藏8个Image
        foreach (Image img in uiImages)
        {
            if (img != null)
                img.gameObject.SetActive(false);
        }
        
        // 隐藏主文本
        if (tipsText != null)
            tipsText.gameObject.SetActive(false);
            
        // 新增：隐藏3个额外文本
        foreach (TextMeshProUGUI text in additionalTexts)
        {
            if (text != null)
                text.gameObject.SetActive(false);
        }
    }

    // 玩家进入触发范围
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInRange = true;
        }
    }

    // 玩家离开触发范围
    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInRange = false;
        }
    }
}