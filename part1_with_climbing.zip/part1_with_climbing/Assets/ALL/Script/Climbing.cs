// 攀爬功能实现
// 交互按键 S 可在第15行修改
// layer：可攀爬墙壁的layer设置为“Climb”

using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class WallClimbingSystem : MonoBehaviour
{
    [Header("Climbing Settings")]
    [SerializeField] private LayerMask climbingWallLayer; // 可攀爬墙壁层
    [SerializeField] private float climbSpeed = 5f;       // 爬墙速度
    [SerializeField] private float wallSnapDistance = 0.1f; // 吸附到墙壁的距离

    [SerializeField] private KeyCode climbKey = KeyCode.S; // 攀爬触发键，可根据实际修改

    [Header("Rotation Settings")]
    [SerializeField] private float rotationSpeed = 10f;    // 旋转速度
    [SerializeField] private float upsideDownAngle = 180f; // 颠倒旋转角度

    // 内部状态
    private bool isClimbing = false;
    private Vector2 wallNormal; // 墙壁法线方向
    private Vector2 wallPoint;  // 碰撞点位置
    private Quaternion targetRotation; // 目标旋转
    private Rigidbody2D rb;
    private float originalGravityScale;

    // 方向枚举
    private enum WallDirection { Right, Left, Up, Down }
    private WallDirection currentWallDirection;

    private bool contactClimbingWall = false;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        originalGravityScale = rb.gravityScale;
    }

    void Update()
    {
        // 检测攀爬键输入
        if (Input.GetKeyDown(climbKey))
        {
            if (isClimbing)
            {
                // 如果已经在攀爬状态，则退出
                ExitClimbingState();
            }
            else if (CanStartClimbing())
            {
                // 如果可以开始攀爬，则进入状态
                EnterClimbingState();
            }
        }
    }

    void FixedUpdate()
    {
        if (isClimbing)
        {
            HandleClimbingMovement();
            HandleRotation();
        }
    }

    // 检测是否可以开始攀爬
    private bool CanStartClimbing()
    {
        if (contactClimbingWall == false) return false; // 与攀爬墙壁接触时才可以攀爬
        // 使用射线检测周围的攀爬墙
        RaycastHit2D hitRight = Physics2D.Raycast(transform.position, Vector2.right, 1f, climbingWallLayer);
        RaycastHit2D hitLeft = Physics2D.Raycast(transform.position, Vector2.left, 1f, climbingWallLayer);
        RaycastHit2D hitUp = Physics2D.Raycast(transform.position, Vector2.up, 1f, climbingWallLayer);
        RaycastHit2D hitDown = Physics2D.Raycast(transform.position, Vector2.down, 1f, climbingWallLayer);

        // 确定最近的墙壁
        float minDistance = Mathf.Infinity;
        RaycastHit2D closestHit = new RaycastHit2D();

        if (hitRight && hitRight.distance < minDistance)
        {
            minDistance = hitRight.distance;
            closestHit = hitRight;
            currentWallDirection = WallDirection.Right;
        }

        if (hitLeft && hitLeft.distance < minDistance)
        {
            minDistance = hitLeft.distance;
            closestHit = hitLeft;
            currentWallDirection = WallDirection.Left;
        }

        if (hitUp && hitUp.distance < minDistance)
        {
            minDistance = hitUp.distance;
            closestHit = hitUp;
            currentWallDirection = WallDirection.Up;
        }

        if (hitDown && hitDown.distance < minDistance)
        {
            minDistance = hitDown.distance;
            closestHit = hitDown;
            currentWallDirection = WallDirection.Down;
        }

        if (closestHit.collider != null)
        {
            wallNormal = closestHit.normal;
            wallPoint = closestHit.point;
            return true;
        }

        return false;
    }

    // 进入攀爬状态
    private void EnterClimbingState()
    {
        isClimbing = true;

        // 禁用重力
        rb.gravityScale = 0;

        // 停止所有运动
        rb.velocity = Vector2.zero;

        // 根据墙壁方向设置目标旋转
        SetTargetRotation();

        // 将角色吸附到墙壁
        SnapToWall();
    }

    // 退出攀爬状态
    private void ExitClimbingState()
    {
        isClimbing = false;

        // 停止所有运动
        rb.velocity = Vector2.zero;

        // 恢复重力
        rb.gravityScale = originalGravityScale;

        // 恢复原始旋转
        targetRotation = Quaternion.identity; // Quaternion.identity意为单位四元数（0，0，0，1），任何向量/旋转与之相乘都不会改变结果
        transform.rotation = targetRotation;
    }

    // 设置目标旋转
    private void SetTargetRotation()
    {
        switch (currentWallDirection)
        {
            case WallDirection.Right:
                targetRotation = Quaternion.Euler(0, 0, 90f);
                break;
            case WallDirection.Left:
                targetRotation = Quaternion.Euler(0, 0, -90f);
                break;
            case WallDirection.Up:
                targetRotation = Quaternion.Euler(0, 0, upsideDownAngle);
                break;
            case WallDirection.Down:
                ExitClimbingState(); // 如果旋转方向和自身方向相同，不需要进行旋转
                break;
        }
    }

    // 吸附到墙壁
    private void SnapToWall()
    {
        Vector2 snapPosition = wallPoint + wallNormal * wallSnapDistance;
        rb.position = snapPosition;
    }

    // 处理攀爬移动
    private void HandleClimbingMovement()
    {
        // 获取水平输入（A/D键）
        float horizontalInput = Input.GetAxis("Horizontal");

        // 根据当前旋转状态确定移动方向
        Vector2 moveDirection = Vector2.zero;

        switch (currentWallDirection)
        {
            case WallDirection.Right:
                moveDirection = Vector2.up * horizontalInput;
                break;
            case WallDirection.Left:
                moveDirection = Vector2.down * horizontalInput;
                break;
            case WallDirection.Up:
                moveDirection = Vector2.right * horizontalInput;
                break;
            case WallDirection.Down:
                moveDirection = Vector2.left * horizontalInput;
                break;
        }

        // 应用速度
        rb.velocity = moveDirection * climbSpeed;
    }

    // 处理旋转
    private void HandleRotation()
    {
        // 平滑旋转到目标角度
        transform.rotation = Quaternion.Lerp(
            transform.rotation,
            targetRotation,
            rotationSpeed * Time.fixedDeltaTime
        );
    }

    // 调试可视化
    void OnDrawGizmosSelected()
    {
        if (isClimbing)
        {
            Gizmos.color = Color.cyan;
            Gizmos.DrawSphere(wallPoint, 0.1f);
            Gizmos.DrawLine(wallPoint, wallPoint + wallNormal);

            Gizmos.color = Color.green;
            Gizmos.DrawWireSphere(rb.position, 0.15f);
        }
    }

    // 碰撞逻辑检验：test角色是否和可攀爬墙壁接触（碰撞）
    private void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.layer == LayerMask.NameToLayer("Climb"))
        {
            contactClimbingWall = true;
            Debug.Log("collision with climbing wall");
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Climb"))
        {
            contactClimbingWall = false;
            Debug.Log("collision end with climbing wall");

            if (isClimbing) ExitClimbingState();
            // 攀爬状态检测，如果攀爬过程中不再和Climb图层元素接触/碰撞，则退出攀爬状态
            // layer要求：攀爬的墙壁必须应用composite collider，否则会导致异常下落
        }
    }
}






/*using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class WallClimbingSystem : MonoBehaviour
{
    [Header("Climbing Settings")]
    [SerializeField] private LayerMask climbingWallLayer;
    [SerializeField] private float climbSpeed = 5f;
    [SerializeField] private float rotationSpeed = 20f; // 更快的旋转速度
    [SerializeField] private KeyCode climbKey = KeyCode.S;
    [SerializeField] private float contactThreshold = 0.1f; // 接触检测阈值

    [Header("Collider Settings")]
    [SerializeField] private Vector2 playerSize = new Vector2(0.5f, 1f); // 玩家碰撞体尺寸
    [SerializeField] private float skinWidth = 0.01f; // 皮肤宽度防止穿透

    // 内部状态
    private bool isClimbing = false;
    private Vector2 wallNormal;
    private Vector2 contactPoint;
    private Quaternion targetRotation;
    private Rigidbody2D rb;
    private float originalGravityScale;
    private Collider2D currentWallCollider; // 当前接触的墙壁碰撞体

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        originalGravityScale = rb.gravityScale;
    }

    void Update()
    {
        // 仅在接触墙壁时检测攀爬输入
        if (currentWallCollider != null && Input.GetKeyDown(climbKey))
        {
            if (!isClimbing)
            {
                EnterClimbingState();
            }
            else
            {
                ExitClimbingState();
            }
        }

        // 自动退出状态检测
        if (isClimbing && !IsStillContactingWall())
        {
            ExitClimbingState();
        }
    }

    void FixedUpdate()
    {
        if (isClimbing)
        {
            HandleClimbingMovement();
            HandleRotation();
            MaintainWallContact(); // 确保持续接触
        }
    }

    // 碰撞检测 - 仅当直接接触墙壁时
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (((1 << collision.gameObject.layer) & climbingWallLayer) != 0)
        {
            // 只考虑垂直或水平表面
            if (IsValidWallSurface(collision.GetContact(0).normal))
            {
                currentWallCollider = collision.collider;
                wallNormal = collision.GetContact(0).normal;
                contactPoint = collision.GetContact(0).point;
            }
        }
    }

    void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.collider == currentWallCollider)
        {
            currentWallCollider = null;
            if (isClimbing)
            {
                ExitClimbingState();
            }
        }
    }

    // 进入攀爬状态
    private void EnterClimbingState()
    {
        isClimbing = true;
        rb.gravityScale = 0;
        rb.velocity = Vector2.zero;

        // 基于接触点计算目标旋转
        SetTargetRotationBasedOnContact();

        // 精确吸附到墙壁表面
        SnapToWallSurface();
    }

    // 退出攀爬状态
    private void ExitClimbingState()
    {
        isClimbing = false;
        rb.gravityScale = originalGravityScale;

        // 立即重置旋转
        transform.rotation = Quaternion.identity;
    }

    // 基于接触点设置旋转
    private void SetTargetRotationBasedOnContact()
    {
        // 根据法线方向确定旋转
        if (Mathf.Abs(wallNormal.x) > Mathf.Abs(wallNormal.y))
        {
            // 垂直墙壁
            targetRotation = Quaternion.Euler(0, 0, wallNormal.x > 0 ? 90f : -90f);
        }
        else
        {
            // 水平墙壁
            targetRotation = Quaternion.Euler(0, 0, wallNormal.y > 0 ? 180f : 0f);
        }
    }

    // 精确吸附到墙壁表面
    private void SnapToWallSurface()
    {
        // 计算角色边界
        Bounds playerBounds = new Bounds(transform.position, playerSize);

        // 计算偏移量 - 确保角色表面与墙壁接触
        Vector2 offset = wallNormal * (playerBounds.extents.magnitude + skinWidth);

        // 应用位置修正
        rb.position = contactPoint + offset;
    }

    // 处理攀爬移动
    private void HandleClimbingMovement()
    {
        float horizontalInput = Input.GetAxis("Horizontal");
        Vector2 moveDirection = Vector2.zero;

        // 根据当前旋转状态确定移动方向
        float currentAngle = transform.eulerAngles.z;

        if (Mathf.Approximately(currentAngle, 0f) || Mathf.Approximately(currentAngle, 180f))
        {
            // 正常或颠倒状态
            moveDirection = Vector2.right * horizontalInput;
        }
        else if (Mathf.Approximately(currentAngle, 90f))
        {
            // 右侧墙壁
            moveDirection = Vector2.up * horizontalInput;
        }
        else if (Mathf.Approximately(currentAngle, 270f) || Mathf.Approximately(currentAngle, -90f))
        {
            // 左侧墙壁
            moveDirection = Vector2.down * horizontalInput;
        }

        rb.velocity = moveDirection * climbSpeed;
    }

    // 处理旋转
    private void HandleRotation()
    {
        // 直接设置旋转，不使用Lerp
        transform.rotation = targetRotation;
    }

    // 确保角色保持墙壁接触
    private void MaintainWallContact()
    {
        // 向墙壁方向发射射线确保接触
        RaycastHit2D hit = Physics2D.Raycast(
            transform.position,
            -transform.right, // 使用角色右侧方向（旋转后）
            playerSize.x / 2 + contactThreshold,
            climbingWallLayer
        );

        if (!hit)
        {
            ExitClimbingState();
        }
    }

    // 检查是否仍然接触墙壁
    private bool IsStillContactingWall()
    {
        // 使用BoxCast检测接触
        Vector2 size = playerSize * 0.9f; // 稍小的尺寸防止边缘检测
        float angle = transform.eulerAngles.z;

        RaycastHit2D hit = Physics2D.BoxCast(
            transform.position,
            size,
            angle,
            -transform.right, // 旋转后的右侧方向
            contactThreshold,
            climbingWallLayer
        );

        return hit.collider != null && hit.collider == currentWallCollider;
    }

    // 检查是否为有效墙壁表面
    private bool IsValidWallSurface(Vector2 normal)
    {
        // 只接受垂直或水平表面
        float angle = Vector2.Angle(normal, Vector2.up);
        return (angle < 30f) || (angle > 60f && angle < 120f) || (angle > 150f);
    }

    // 调试可视化
    void OnDrawGizmosSelected()
    {
        if (isClimbing)
        {
            // 绘制接触点
            Gizmos.color = Color.cyan;
            Gizmos.DrawSphere(contactPoint, 0.05f);

            // 绘制角色边界
            Gizmos.color = Color.green;
            Gizmos.DrawWireCube(transform.position, playerSize);

            // 绘制墙壁检测方向
            Gizmos.color = Color.red;
            Gizmos.DrawRay(transform.position, -transform.right * (playerSize.x / 2 + contactThreshold));
        }
    }
}*/