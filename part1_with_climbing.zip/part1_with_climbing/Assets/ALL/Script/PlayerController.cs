using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(Collider2D))]
public class PlayerController : MonoBehaviour
{
    [Header("��ұ�ʶ")]
    public bool isPlayer1 = true; // ��ʶ�Ƿ�Ϊ���1

    [Header("��λ����")]
    public KeyCode leftKey = KeyCode.A;
    public KeyCode rightKey = KeyCode.D;
    public KeyCode jumpKey = KeyCode.W;
    public KeyCode downKey = KeyCode.S;
    public KeyCode spawnKey = KeyCode.Q;

    [Header("�ƶ�����")]
    public float moveSpeed = 5f;
    public float jumpForce = 8f;

    [Header("������")]
    public LayerMask groundLayer;
    public Transform groundCheck;
    public float groundCheckRadius = 0.1f;

    [Header("���ɶ�������")]
    public GameObject objectPrefab;
    public Transform spawnPoint;

    [Header("����������")]
    public Animator[] animators; // ����������
    public GameObject[] animatorObjects; // ��Ӧ�������Ķ���

    [Header("������ײЧ��")]
    public GameObject risingRectanglePrefab; // ������Ԥ����
    public float rectangleRiseSpeed = 5f;   // �����������ٶ�
    public float rectangleLifeTime = 1.5f;  // �����δ���ʱ��

    [Header("��߳���������")]
    public GameObject growingRectanglePrefab; // ��ʱ���ߵĳ�����Ԥ����
    public float rectangleGrowthRate = 0.5f;  // ÿ���������ĸ߶�
    public float rectangleGrowthTime = 3f;    // ��������ʱ��
    public float rectangleFallDuration = 0.5f; // ���¶�������ʱ��
    public LayerMask rectangleGroundLayer;    // �����μ��ĵ����

    private Rigidbody2D rb;
    private Collider2D col;
    private bool isGrounded;
    private Vector3 originScale;
    private PlatformEffector2D platformEffector;

    private GameObject currentSpawnedObject;

    public int index = 0; // ��ǰ index��ѭ�� 0-2

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        col = GetComponent<Collider2D>();
        originScale = transform.localScale;
    }

    private void Update()
    {
        // ������
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);

        // �����ƶ�
        float moveInput = 0;
        if (Input.GetKey(leftKey))
            moveInput = -1;
        else if (Input.GetKey(rightKey))
            moveInput = 1;

        rb.velocity = new Vector2(moveInput * moveSpeed, rb.velocity.y);

        // ����
        if (moveInput > 0)
            transform.localScale = new Vector3(Mathf.Abs(originScale.x), originScale.y, originScale.z);
        else if (moveInput < 0)
            transform.localScale = new Vector3(-Mathf.Abs(originScale.x), originScale.y, originScale.z);

        // ��Ծ
        if (Input.GetKeyDown(jumpKey) && isGrounded && rb.gravityScale > 0f)
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
        }

        // ���䴩͸ƽ̨
        if (Input.GetKeyDown(downKey) && isGrounded)
        {
            if (col != null && col.IsTouchingLayers(groundLayer))
            {
                platformEffector = GetPlatformEffectorBelow();
                if (platformEffector != null)
                {
                    StartCoroutine(DisableCollisionTemporarily());
                }
            }
        }

        // �л� index�����޸����ɶ��� index��
        if (Input.GetKeyDown(spawnKey))
        {
            index = (index + 1) % 3;
            UpdateAnimatorState();

            if (currentSpawnedObject == null)
            {
                // �����¶���
                Vector3 spawnPos = spawnPoint != null ? spawnPoint.position : transform.position;
                currentSpawnedObject = Instantiate(objectPrefab, spawnPos, Quaternion.identity);

                FollowPlayerElement follow = currentSpawnedObject.GetComponent<FollowPlayerElement>();
                if (follow != null)
                {
                    follow.target = spawnPoint;
                    follow.index = index;
                    follow.isPlayer1 = this.isPlayer1; // ������ұ�ʶ
                    follow.ApplyAppearance();
                }
            }
            else
            {
                // ���ж��󣬸��� index
                FollowPlayerElement follow = currentSpawnedObject.GetComponent<FollowPlayerElement>();
                if (follow != null)
                {
                    follow.index = index;
                    follow.isPlayer1 = this.isPlayer1; // ������ұ�ʶ
                    follow.ApplyAppearance();
                }
            }
        }

        // ���¶�������
        for (int i = 0; i < animators.Length; i++)
        {
            if (animators[i] != null && animatorObjects[i].activeSelf)
            {
                animators[i].SetBool("isRun", Mathf.Abs(moveInput) > 0.1f);
                animators[i].SetBool("isJump", !isGrounded && rb.gravityScale > 0f);
            }
        }
    }

    private void UpdateAnimatorState()
    {
        // �������ж���������ֻ���ǰ index���ر�����
        for (int i = 0; i < animatorObjects.Length; i++)
        {
            if (animatorObjects[i] != null)
            {
                animatorObjects[i].SetActive(i == index);
            }
        }
    }

    private PlatformEffector2D GetPlatformEffectorBelow()
    {
        RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.down, 1f, groundLayer);
        if (hit.collider != null)
        {
            return hit.collider.GetComponent<PlatformEffector2D>();
        }
        return null;
    }

    private System.Collections.IEnumerator DisableCollisionTemporarily()
    {
        col.enabled = false;
        yield return new WaitForSeconds(0.3f);
        col.enabled = true;
    }

    private void OnDrawGizmosSelected()
    {
        if (groundCheck != null)
        {
            Gizmos.color = Color.green;
            Gizmos.DrawWireSphere(groundCheck.position, groundCheckRadius);
        }
    }
}