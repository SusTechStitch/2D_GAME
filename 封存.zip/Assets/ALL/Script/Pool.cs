using UnityEngine;

public class Pool : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        PlayerController player = collision.GetComponent<PlayerController>();

        if (player != null)
        {
            if (player.index != 1)
            {
                Debug.Log($"{collision.name} û��ˮ����(index={player.index})����ˮ��û�ˣ�");
                Destroy(collision.gameObject);
            }
            else
            {
                Debug.Log($"{collision.name} ӵ��ˮ����(index=1)������ˮ����Ӿ��");
                player.SetInWater(true); // ֪ͨ��ҽ���ˮ��
            }
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        PlayerController player = collision.GetComponent<PlayerController>();

        if (player != null && player.index == 1)
        {
            Debug.Log($"{collision.name} �뿪ˮ��");
            player.SetInWater(false); // ֪ͨ����뿪ˮ��
        }
    }
}