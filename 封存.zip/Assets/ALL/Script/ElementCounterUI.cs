using UnityEngine;
using TMPro; // ����TextMeshPro�����ռ�

public class ElementCounterUI : MonoBehaviour
{
    [Header("Ԫ����ʾ����")]
    public TMP_Text element0Text; // ʹ��TMP_Text���Text
    public TMP_Text element1Text;
    public TMP_Text element2Text;

    [Header("Ԫ������")]
    public string[] elementNames = new string[] { "��Ԫ��", "ˮԪ��", "��Ԫ��" };

    [Header("ˢ����")]
    [Tooltip("UIˢ�¼�����룩")]
    public float updateInterval = 0.2f;

    private float timer;

    private void Start()
    {
        // �����Զ�����TextMeshPro����
        AutoFindTextObjects();
        UpdateUI();
    }

    // �Զ�����TextMeshPro����
    private void AutoFindTextObjects()
    {
        if (element0Text == null)
            element0Text = GameObject.Find("Element0Text")?.GetComponent<TMP_Text>();
        if (element1Text == null)
            element1Text = GameObject.Find("Element1Text")?.GetComponent<TMP_Text>();
        if (element2Text == null)
            element2Text = GameObject.Find("Element2Text")?.GetComponent<TMP_Text>();
    }

    private void Update()
    {
        timer += Time.deltaTime;
        if (timer >= updateInterval)
        {
            timer = 0;
            UpdateUI();
        }
    }

    private void UpdateUI()
    {
        if (element0Text != null)
            element0Text.text = $"{elementNames[0]}: {ElementCounter.GetCount(0)}";
        else
            Debug.LogWarning("element0Textδ����");

        if (element1Text != null)
            element1Text.text = $"{elementNames[1]}: {ElementCounter.GetCount(1)}";
        else
            Debug.LogWarning("element1Textδ����");

        if (element2Text != null)
            element2Text.text = $"{elementNames[2]}: {ElementCounter.GetCount(2)}";
        else
            Debug.LogWarning("element2Textδ����");
    }

    // ���ü�������ť�ķ���
    public void ResetCounters()
    {
        ElementCounter.ResetAll();
        UpdateUI();
    }
}