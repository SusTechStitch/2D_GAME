using UnityEngine;
using System.Collections;

public class TreeGeneration : MonoBehaviour
{
    [Header("��ľ����")]
    public GameObject treePrefab;
    public LayerMask groundLayer;
    public Material growthMaterial;
    [Range(0.1f, 2f)] public float widthMultiplier = 0.5f;

    [Header("��������")]
    public float minHeight = 0.5f;
    public float maxHeight = 100f;
    public float growthDuration = 3f;
    public AnimationCurve growthCurve = AnimationCurve.EaseInOut(0, 0, 1, 1);

    public bool autoEnablePhysics = true;

    [Header("�Ӿ�Ч��")]
    public Color newGrowthColor = new Color(0.8f, 0.6f, 0.4f, 1f);
    public bool applyColorGradient = true;

    private bool isGrowing = false;
    private Camera mainCamera;

    void Start()
    {
        mainCamera = Camera.main;
    }

    void Update()
    {
        if (isGrowing) return;

        if (Input.GetMouseButtonDown(0))
        {
            StartCoroutine(GrowTree());
        }
    }

    IEnumerator GrowTree()
    {
        isGrowing = true;

        // ��ȡ�����������
        Vector3 mousePosition = Input.mousePosition;
        Vector3 worldMousePosition = mainCamera.ScreenToWorldPoint(new Vector3(mousePosition.x, mousePosition.y, 0f));

        // ʹ�� Raycast ������
        RaycastHit2D hit = Physics2D.Raycast(worldMousePosition, Vector2.down, Mathf.Infinity, groundLayer);
        if (!hit.collider)
        {
            Debug.LogWarning("δ��⵽���棡");
            isGrowing = false;
            yield break;
        }

        Vector3 groundPosition = hit.point;

        // ����Ŀ��߶ȣ��ӵ��浽���� y ��ֵ��
        float targetHeight = worldMousePosition.y - groundPosition.y;
        targetHeight = Mathf.Clamp(targetHeight, minHeight, maxHeight);

        // ��ʼ����λ�ã��ײ����أ�scale.y = 0
        Vector3 spawnPosition = new Vector3(
            groundPosition.x,
            groundPosition.y,
            0f
        );

        GameObject tree = Instantiate(treePrefab, spawnPosition, Quaternion.identity);
        tree.name = $"Tree_{Time.time}";

        // ��ʼ������
        Renderer treeRenderer = tree.GetComponentInChildren<Renderer>();
        Material appliedMaterial = null;
        Color initialColor = Color.white;

        if (treeRenderer != null)
        {
            appliedMaterial = growthMaterial != null ? new Material(growthMaterial) : new Material(treeRenderer.material);
            treeRenderer.material = appliedMaterial;

            if (applyColorGradient)
            {
                initialColor = appliedMaterial.color;
                appliedMaterial.color = newGrowthColor;
            }
        }

        // ����
        Rigidbody2D rb = tree.GetComponent<Rigidbody2D>();
        if (rb == null) rb = tree.AddComponent<Rigidbody2D>();
        rb.simulated = false;
        rb.gravityScale = 0;

        // ��ʱ��ײ��
        BoxCollider2D growthCollider = tree.AddComponent<BoxCollider2D>();
        growthCollider.isTrigger = true;
        growthCollider.size = new Vector2(widthMultiplier, 0.01f);

        float elapsed = 0f;
        while (elapsed < growthDuration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / growthDuration);
            float curveT = growthCurve.Evaluate(t);

            float currentHeight = Mathf.Lerp(0f, targetHeight, curveT);

            // ��������
            tree.transform.localScale = new Vector3(
                widthMultiplier,
                currentHeight,
                1f
            );

            // ��֤�ײ�ʼ���ڵ���
            tree.transform.position = new Vector3(
                groundPosition.x,
                groundPosition.y + currentHeight / 2,
                0f
            );

            // ������ʱ��ײ��
            growthCollider.size = new Vector2(widthMultiplier, currentHeight);

            // ������ɫ
            if (applyColorGradient && appliedMaterial != null)
            {
                appliedMaterial.color = Color.Lerp(newGrowthColor, initialColor, curveT);
            }

            yield return null;
        }

        // ���һ�ε���
        tree.transform.localScale = new Vector3(widthMultiplier, targetHeight, 1f);
        tree.transform.position = new Vector3(
            groundPosition.x,
            groundPosition.y + targetHeight / 2,
            0f
        );

        // �Ƴ���ʱ��ײ�壬����ʽ��
        Destroy(growthCollider);

        BoxCollider2D finalCollider = tree.AddComponent<BoxCollider2D>();
        finalCollider.size = new Vector2(widthMultiplier, targetHeight);

        if (autoEnablePhysics)
        {
            rb.simulated = true;
            rb.gravityScale = 1f;
            rb.constraints = RigidbodyConstraints2D.FreezeRotation;
        }

        Debug.Log($"��ľ������� | �߶�: {targetHeight}");

        isGrowing = false;
    }
}
