using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player1Input : PlayerInputHandler
{
    public override float GetHorizontalRaw() => Input.GetAxisRaw("Horizontal");
    public override float GetVerticalRaw() => Input.GetAxis("Vertical");
    public override bool JumpPressed() => Input.GetKey(KeyCode.W);
    public override bool DashPressed() => Input.GetKeyDown(KeyCode.LeftShift);
    public override bool PrimaryAttackPressed() => Input.GetMouseButtonDown(0);
    public override bool ElementSummonPressed() => Input.GetKeyDown(KeyCode.R);
    public override bool TreeConfirmPressed() => Input.GetKeyDown(KeyCode.Space);
    public override Vector2 GetMousePosition() => Input.mousePosition;
}
