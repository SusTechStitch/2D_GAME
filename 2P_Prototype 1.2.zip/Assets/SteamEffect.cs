// SteamEffect.cs
using UnityEngine;

public class SteamEffect : MonoBehaviour
{
    public float riseSpeed = 1.5f;
    public float fadeSpeed = 0.5f;

    private SpriteRenderer spriteRenderer;

    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        Destroy(gameObject, 3.0f); // 3����Զ�����
    }

    private void Update()
    {
        // �����ƶ�
        transform.Translate(Vector3.up * riseSpeed * Time.deltaTime);

        // ����ʧ
        Color color = spriteRenderer.color;
        color.a -= fadeSpeed * Time.deltaTime;
        spriteRenderer.color = color;
    }
}