using UnityEngine;
using UnityEngine.UI;

public class InteractPrompt : MonoBehaviour
{
    public GameObject promptPanel;
    public Text promptText;
    public string interactMessage = "Press [P] to destroy";

    private IceBlock targetIceBlock;

    void Update()
    {
        // ������ʾλ��
        if (targetIceBlock != null)
        {
            UpdatePromptPosition();
        }
    }

    public void ShowPrompt(IceBlock iceBlock)
    {
        targetIceBlock = iceBlock;

        if (promptPanel != null)
        {
            promptPanel.SetActive(true);

            if (promptText != null)
            {
                promptText.text = interactMessage.Replace("[P]", "P");
            }
        }
    }

    public void HidePrompt()
    {
        if (promptPanel != null)
        {
            promptPanel.SetActive(false);
        }
        targetIceBlock = null;
    }

    private void UpdatePromptPosition()
    {
        // ����ʾ��ʾ�ڱ����Ϸ�
        Vector3 screenPos = Camera.main.WorldToScreenPoint(targetIceBlock.transform.position + Vector3.up * 1f);
        transform.position = screenPos;
    }
}