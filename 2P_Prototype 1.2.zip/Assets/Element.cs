using UnityEngine;

public class Element : MonoBehaviour
{
    public enum ElementType { Fire, Water, Wood , None }
    public ElementType type;
    public Player owner;

    private void Start()
    {
        // ����Ԫ�ر�ǩ���ڼ��
        switch (type)
        {
            case ElementType.Fire:
                gameObject.tag = "FireElement";
                break;
            case ElementType.Water:
                gameObject.tag = "WaterElement";
                break;
            case ElementType.Wood:
                gameObject.tag = "WoodElement";
                break;
        }

        // ע�ᵽ����������
        if (ElementInteractionManager.Instance != null)
        {
            ElementInteractionManager.Instance.RegisterElement(this);
        }
    }

    private void OnDestroy()
    {
        // ֪ͨ���Ԫ�ر�����
        if (owner != null)
        {
            owner.OnElementDestroyed();
        }

        // �ӽ���������ע��
        if (ElementInteractionManager.Instance != null)
        {
            ElementInteractionManager.Instance.UnregisterElement(this);
        }
    }

    public float GetSize()
    {
        // ����Ԫ����ײ���С
        Collider2D collider = GetComponent<Collider2D>();
        if (collider != null)
        {
            if (collider is CircleCollider2D circleCollider)
            {
                return circleCollider.radius * transform.localScale.x;
            }
            else if (collider is BoxCollider2D boxCollider)
            {
                return Mathf.Max(boxCollider.size.x, boxCollider.size.y) * 0.5f * transform.localScale.x;
            }
        }

        // Ĭ�ϴ�С
        return 0.5f;
    }
}