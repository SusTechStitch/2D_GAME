using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : Entity
{
    [SerializeField] protected LayerMask whatisPlayer;


    [Header("Stunned Info")]
    public float StunDuration;
    public Vector2 StunDirection;
    protected bool canbeStunned;
    [SerializeField] protected GameObject counterImage;


    [Header("Move Info")]
    public float moveSpeed;
    public float idolTime;
    public float battleTime; 


    [Header("Attack Info")]
    public float attackDistance;
    public float attackCoolDown;
    [HideInInspector] public float lastTimeAttacked; 

    public EnemyStateMachine stateMachine { get; private set; }

    protected override void Awake()
    {
        base.Awake(); 
        stateMachine = new EnemyStateMachine(); 
    }

    protected override void Update()
    {
        base.Update(); 
        stateMachine.currentState.Update();

    }

    public virtual void OpenCounterAttackWindow()
    {
        canbeStunned = true;
        counterImage.SetActive(true);
    }

    public virtual void CloseCounterAttackWindow()
    {
        canbeStunned = false;
        counterImage.SetActive(false);
    }

    public virtual bool CanBeStunned()
    {
        if (canbeStunned)
        {
            CloseCounterAttackWindow();
            return true; 
        }

        return false; 
    }



    public virtual void AnimationFinishTrigger() => stateMachine.currentState.AnimationFinishTrigger();


    public virtual RaycastHit2D isPlayerDetected() => Physics2D.Raycast(wallcheck.position, Vector2.right * facingDir, 50, whatisPlayer);


    protected override void OnDrawGizmos()
    {
        base.OnDrawGizmos();

        Gizmos.color = Color.yellow;
        Gizmos.DrawLine(transform.position, new Vector3(transform.position.x + attackDistance * facingDir, transform.position.y));

    }



}
