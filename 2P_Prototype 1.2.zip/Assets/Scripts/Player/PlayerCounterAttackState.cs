using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCounterAttackState : PlayerState
{
    public PlayerCounterAttackState(Player _player, PlayerStateMachine _statemachine, string _animeboolname) : base(_player, _statemachine, _animeboolname)
    {
    }

    public override void Enter()
    {
        base.Enter();

        statetimer = player.counterAttackDuration;
        player.anime.SetBool("SuccessfulCounterAttack", false);
    }

    public override void Exit()
    {
        base.Exit();
    }

    public override void Update()
    {
        base.Update();

        player.SetZeroVelocity();

        Collider2D[] colliders = Physics2D.OverlapCircleAll(player.attackCheck.position, player.attackCheckRadios);


        foreach (var hit in colliders)
        {
            if (hit.GetComponent<Enemy>() != null)
            {
                if (hit.GetComponent<Enemy>().CanBeStunned())
                {
                    statetimer = 10;
                    player.anime.SetBool("SuccessfulCounterAttack", true);

                }
            }
        }

        if (statetimer < 0 || triggercalled)
        {
            statemachine.ChangeState(player.idolstate);
        }




    }
}
