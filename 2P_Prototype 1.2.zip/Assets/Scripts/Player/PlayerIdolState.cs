using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerIdolState : PlayerGroundedState
{
    public PlayerIdolState(Player _player, PlayerStateMachine _statemachine, string _animeboolname) : base(_player, _statemachine, _animeboolname)
    {

    }

    public override void Enter()
    {
        base.Enter();
        rb.velocity = new Vector2(0, 0); 
    }

    public override void Exit()
    {
        base.Exit();
    }

    public override void Update()
    {
        base.Update();
        if ( player.InputHandler.GetHorizontalRaw() != 0 && !player.isBusy )
        {
            statemachine.ChangeState(player.moveState); 
        }
    }

}   
