using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : Entity
{
    public bool isBusy { get; private set; }
    [Header("Attack Details")]
    public Vector2[] AttackMovement;
    public float counterAttackDuration = .2f;

    [Header("Move Info")]
    public float movespeed = 12f;
    public float jumpforce;
    public float SwordReturnImpact;

    [Header("Dash Info")]
    public float dashSpeed;
    public float dashDuration;
    public float dashDir { get; private set; }

    [Header("Element Settings")]
    public float elementDistance = 1.5f;
    public GameObject[] elementPrefabs;
    public Transform elementHolder;

    private GameObject currentElement;
    public Element CurrentElement { get; private set; } // ������ǰԪ��

    // Ԫ������ö��
    public enum ElementType { None, Fire, Water, Wood }
    private ElementType currentElementType = ElementType.None;

    [Header("Interaction Settings")]
    public float interactionRange = 1.0f; // ��ҽ�����Χ
    public LayerMask interactableLayer; // �ɽ�������Ĳ㼶

    private IceBlock nearbyIceBlock; // �����ı���

    public SkillManager skill { get; private set; }
    public GameObject sword { get; private set; }

    // ����ϵͳ�ӿ�
    public PlayerInputHandler InputHandler { get; private set; }

    #region States
    public PlayerStateMachine statemachine { get; private set; }
    public PlayerIdolState idolstate { get; private set; }
    public PlayerMoveState moveState { get; private set; }
    public PlayerJumpState JumpState { get; private set; }
    public PlayerAirState AirState { get; private set; }
    public PlayerWallSlideState WallSlideState { get; private set; }
    public PlayerWallJumpState WallJumpState { get; private set; }
    public PlayerDashState DashState { get; private set; }
    public PlayerPrimaryAttack PrimaryAttack { get; private set; }
    public PlayerCounterAttackState CounterAttack { get; private set; }
    public PlayerAimSwordState AimSword { get; private set; }
    public PlayerCatchSwordState CatchSword { get; private set; }
    #endregion

    // ��ʼ���������ϵͳ
    public void InitializePlayer(PlayerInputHandler inputHandler)
    {
        InputHandler = inputHandler;
    }

    protected override void Awake()
    {
        base.Awake();

        statemachine = new PlayerStateMachine();

        // ��ʼ������״̬
        idolstate = new PlayerIdolState(this, statemachine, "isIdol");
        moveState = new PlayerMoveState(this, statemachine, "isMove");
        JumpState = new PlayerJumpState(this, statemachine, "Jump");
        AirState = new PlayerAirState(this, statemachine, "Jump");
        WallSlideState = new PlayerWallSlideState(this, statemachine, "WallSlide");
        WallJumpState = new PlayerWallJumpState(this, statemachine, "Jump");
        DashState = new PlayerDashState(this, statemachine, "Dash");
        PrimaryAttack = new PlayerPrimaryAttack(this, statemachine, "Attack");
        CounterAttack = new PlayerCounterAttackState(this, statemachine, "CounterAttack");
        AimSword = new PlayerAimSwordState(this, statemachine, "AimSword");
        CatchSword = new PlayerCatchSwordState(this, statemachine, "CatchSword");
    }

    protected override void Start()
    {
        base.Start();
        skill = SkillManager.instance;
        statemachine.Initialize(idolstate);
        CreateElementHolder();
    }

    protected override void Update()
    {
        base.Update();
        statemachine.currentstate.Update();
        CheckforDashInput();

        // ���Ԫ���ٻ�����
        if (InputHandler != null && InputHandler.ElementSummonPressed() && !isBusy)
        {
            SummonElement();
        }

        // ����Ԫ��λ��
        UpdateElementPosition();

        // ��⸽���Ŀɽ�������
        CheckNearbyInteractables();

        // ��⽻������
        if (Input.GetKeyDown(KeyCode.P) && nearbyIceBlock != null)
        {
            nearbyIceBlock.DestroyIceBlock();
        }
    }

    private void CheckNearbyInteractables()
    {
        // ���ø����ı���
        nearbyIceBlock = null;

        // ��⸽���Ľ�������
        Collider2D[] hitColliders = Physics2D.OverlapCircleAll(transform.position, interactionRange, interactableLayer);

        // Ѱ������ı���
        float closestDistance = float.MaxValue;
        foreach (Collider2D hitCollider in hitColliders)
        {
            IceBlock iceBlock = hitCollider.GetComponent<IceBlock>();
            if (iceBlock != null)
            {
                float distance = Vector2.Distance(transform.position, hitCollider.transform.position);
                if (distance < closestDistance)
                {
                    closestDistance = distance;
                    nearbyIceBlock = iceBlock;
                }
            }
        }
    }

    private void CreateElementHolder()
    {
        // ����Ԫ�ظ���ο���
        GameObject holder = new GameObject("ElementHolder");
        holder.transform.SetParent(transform);

        // ������ҷ������ó�ʼλ��
        float offsetX = facingDir == 1 ? elementDistance : -elementDistance;
        holder.transform.localPosition = new Vector3(offsetX, 0.5f, 0);

        elementHolder = holder.transform;
    }

    // �����������ٻ�Ԫ��
    private void SummonElement()
    {
        // �����Ҵ���æµ״̬��������Ԫ��
        if (isBusy)
            return;

        StartCoroutine(SummonElementRoutine());
    }

    private IEnumerator SummonElementRoutine()
    {
        isBusy = true;

        // ���ٵ�ǰԪ��
        if (currentElement != null)
        {
            Destroy(currentElement);
            yield return new WaitForEndOfFrame(); // ȷ����ȫ����
        }

        // ȷ����Ԫ������ - �޸�ӳ���ϵ
        if (currentElementType == ElementType.None)
        {
            currentElementType = ElementType.Fire;
        }
        else
        {
            switch (currentElementType)
            {
                case ElementType.Fire:
                    currentElementType = ElementType.Water;
                    break;
                case ElementType.Water:
                    currentElementType = ElementType.Wood;
                    break;
                case ElementType.Wood:
                    currentElementType = ElementType.Fire;
                    break;
            }
        }

        // ������Ԫ�� - �޸���������
        CreateCurrentElement();

        isBusy = false;
    }

    private void CreateCurrentElement()
    {
        // Ԫ�����͵�Ԥ����������ӳ��
        int prefabIndex = -1;

        switch (currentElementType)
        {
            case ElementType.Fire:
                prefabIndex = 0;
                break;
            case ElementType.Water:
                prefabIndex = 1;
                break;
            case ElementType.Wood:
                prefabIndex = 2;
                break;
        }

        // �����ҵ���Ч����ʱ����Ԫ��
        if (prefabIndex >= 0 && prefabIndex < elementPrefabs.Length)
        {
            // ȷ��Ԥ������Ч
            if (elementPrefabs[prefabIndex] != null)
            {
                currentElement = Instantiate(
                    elementPrefabs[prefabIndex],
                    elementHolder.position,
                    elementHolder.rotation
                );

                // ���ø������������
                currentElement.transform.SetParent(elementHolder);
                CurrentElement = currentElement.GetComponent<Element>();
                if (CurrentElement != null)
                {
                    CurrentElement.owner = this;
                    Debug.Log($"����Ԫ��: {CurrentElement.type}");
                }
                else
                {
                    Debug.LogError("Ԫ��Ԥ����ȱ��Element���");
                }
            }
            else
            {
                Debug.LogError($"Ԫ��Ԥ��������{prefabIndex}Ϊ��");
            }
        }
        else
        {
            Debug.LogError($"��Ч��Ԫ������: {prefabIndex}");
        }
    }

    // ��������������Ԫ��λ��
    private void UpdateElementPosition()
    {
        if (elementHolder != null && currentElement != null)
        {
            // ȷ��Ԫ�ظ�����ҷ���
            float offsetX = facingDir == 1 ? elementDistance : -elementDistance;
            elementHolder.localPosition = new Vector3(offsetX, 0.5f, 0);

            currentElement.transform.position = elementHolder.position;
        }
    }

    public void OnElementDestroyed()
    {
        CurrentElement = null;
        currentElement = null;
    }

    public void AssignNewSword(GameObject _newSword)
    {
        sword = _newSword;
    }

    public void CatchTheSword()
    {
        statemachine.ChangeState(CatchSword);
        Destroy(sword);
    }

    public IEnumerator BusyFor(float _seconds)
    {
        isBusy = true;
        yield return new WaitForSeconds(_seconds);
        isBusy = false;
    }

    public void AnimationTrigger() => statemachine.currentstate.AnimationFinishTrigger();

    private void CheckforDashInput()
    {
        if (isWallDetected())
        {
            return;
        }

        // ʹ������ϵͳ����̰���
        if (InputHandler.DashPressed() && SkillManager.instance.dash.CanUseSkill())
        {
            dashDir = InputHandler.GetHorizontalRaw();
            if (dashDir == 0)
            {
                dashDir = facingDir;
            }
            statemachine.ChangeState(DashState);
        }
    }
}