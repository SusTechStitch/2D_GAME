using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Clone_Skill_Controller : MonoBehaviour
{

    private SpriteRenderer sr;
    private Animator anim;


    [SerializeField] private float ColorLosingSpeed; 


    private float CloneTimer;
    [SerializeField] private Transform attackCheck;
    [SerializeField] private float attackCheckRadios = .8f;
    private Transform closestEnemy;


    private void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        anim = GetComponent<Animator>();

    }


    private void Update()
    {
        CloneTimer -= Time.deltaTime; 

        if ( CloneTimer<0 )
        {
            sr.color = new Color(1, 1, 1, sr.color.a - (Time.deltaTime * ColorLosingSpeed));

            if (sr.color.a <= 0)
            {
                Destroy(gameObject);
            }

        }
    }

    public void SetUpClone(Transform _newTransform , float _cloneDuration , bool _canAttack )
    {
        if ( _canAttack)
        {
            anim.SetInteger("AttackNumber", Random.Range(1, 3));
        }

        transform.position = _newTransform.position;

        CloneTimer = _cloneDuration;

        AttackClosestTarget();

    }

    private void AnimationTrigger()
    {
        CloneTimer = -.1f;
    }

    private void AttackTrigger()
    {
        Collider2D[] colliders = Physics2D.OverlapCircleAll(attackCheck.position, attackCheckRadios);

        foreach (var hit in colliders)
        {
            if (hit.GetComponent<Enemy>() != null)
            {
                hit.GetComponent<Enemy>().Damage();
            }
        }
    }

    private void AttackClosestTarget()
    {
        Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, 25);

        float ClosestDistance = Mathf.Infinity;

        foreach(var hit in colliders)
        {
            if ( hit.GetComponent<Enemy>() != null )
            {
                float distancetoEnemy = Vector2.Distance(transform.position, hit.transform.position);

                if (distancetoEnemy < ClosestDistance)
                {
                    ClosestDistance = distancetoEnemy;
                    closestEnemy = hit.transform;
                }
            }
        }


        if (closestEnemy != null )
        {
            if (transform.position.x > closestEnemy.position.x)
            {
                transform.Rotate(0, 180, 0);
            }
        }











    }




}
