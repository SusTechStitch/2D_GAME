using UnityEngine;
using System.Collections;

public class GrowingTree : MonoBehaviour
{
    [Header("Growth Settings")]
    public float growthSpeed = 1.0f;
    public float maxHeight = 8.0f;
    public float maxGrowthTime = 5.0f;

    [Header("Fall Settings")]
    public float fallSpeed = 60.0f;

    private Player owner;
    private float currentHeight;
    private float growthTimer;
    private bool isGrowing = true;
    private bool isFalling;
    private float fallDirection;

    private GameObject leftIndicator;
    private GameObject rightIndicator;
    private Vector3 groundPosition;

    void Start()
    {
        // ��¼��ʼ����λ��
        groundPosition = transform.position;

        // ��ʼ�߶�
        currentHeight = 0.1f;
        transform.localScale = new Vector3(0.3f, currentHeight, 1f);
        transform.position = groundPosition + Vector3.up * currentHeight / 2;

        // ����ָʾ��
        CreateIndicators();
    }

    public void Initialize(Player player)
    {
        owner = player;
        currentHeight = 0.1f;
        growthTimer = maxGrowthTime;
        isGrowing = true;
        isFalling = false;

        // ���ñ任
        transform.localScale = new Vector3(0.3f, currentHeight, 1f);
        transform.rotation = Quaternion.identity;
        transform.position = groundPosition + Vector3.up * currentHeight / 2;

        // ��ʼ����ָʾ��
        if (leftIndicator != null) leftIndicator.SetActive(false);
        if (rightIndicator != null) rightIndicator.SetActive(false);
    }

    private void CreateIndicators()
    {
        // ������ָʾ��
        leftIndicator = CreateIndicator("LeftIndicator", new Vector3(-0.8f, 1f, 0));

        // ������ָʾ��
        rightIndicator = CreateIndicator("RightIndicator", new Vector3(0.8f, 1f, 0));

        // ��ʼ����ָʾ��
        leftIndicator.SetActive(false);
        rightIndicator.SetActive(false);
    }

    private GameObject CreateIndicator(string name, Vector3 localPosition)
    {
        GameObject indicator = new GameObject(name);
        indicator.transform.SetParent(transform);
        indicator.transform.localPosition = localPosition;

        // ���Ӿ�����Ⱦ��
        SpriteRenderer renderer = indicator.AddComponent<SpriteRenderer>();

        // ���������ξ���
        renderer.sprite = CreateTriangleSprite();

        return indicator;
    }

    private Sprite CreateTriangleSprite()
    {
        // ��������������
        int size = 16;
        Texture2D texture = new Texture2D(size, size);

        // ͸������
        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                texture.SetPixel(x, y, Color.clear);
            }
        }

        // ����������
        for (int y = 0; y < size; y++)
        {
            for (int x = y; x < size - y; x++)
            {
                texture.SetPixel(x, y, Color.white);
            }
        }

        texture.Apply();
        return Sprite.Create(texture, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f));
    }

    private void Update()
    {
        if (isGrowing)
        {
            GrowTree();
        }
        else if (isFalling)
        {
            FallTree();
        }
    }

    private void GrowTree()
    {
        if (!isGrowing) return;

        // ���Ӹ߶�
        currentHeight += growthSpeed * Time.deltaTime;
        currentHeight = Mathf.Min(currentHeight, maxHeight);

        // ��������ʱ��
        growthTimer -= Time.deltaTime;

        // ������ľ�Ӿ�
        UpdateTreeVisual();

        // ����Ƿ�ֹͣ����
        if (currentHeight >= maxHeight || growthTimer <= 0)
        {
            StopGrowing();
        }
    }

    private void UpdateTreeVisual()
    {
        // ����ֱ������������ľ
        transform.localScale = new Vector3(0.3f, currentHeight, 1f);

        // ����λ�ã����ֵײ��ڵ��棩
        transform.position = groundPosition + Vector3.up * currentHeight / 2;
    }

    private void StopGrowing()
    {
        isGrowing = false;

        // ��ʾ����ָʾ��
        ShowDirectionIndicators();

        // ��ʼ��������
        StartCoroutine(WaitForDirectionInput());
    }

    private void ShowDirectionIndicators()
    {
        if (leftIndicator != null) leftIndicator.SetActive(true);
        if (rightIndicator != null) rightIndicator.SetActive(true);
    }

    private void HideDirectionIndicators()
    {
        if (leftIndicator != null) leftIndicator.SetActive(false);
        if (rightIndicator != null) rightIndicator.SetActive(false);
    }

    private IEnumerator WaitForDirectionInput()
    {
        bool directionSelected = false;

        while (!directionSelected && owner != null)
        {
            if (owner.InputHandler.TreeConfirmPressed())
            {
                // ��ȡ���λ��
                Vector2 mouseWorldPos = Camera.main.ScreenToWorldPoint(owner.InputHandler.GetMousePosition());

                // ȷ�����µķ���
                fallDirection = mouseWorldPos.x > transform.position.x ? 1 : -1;
                directionSelected = true;
            }
            yield return null;
        }

        // ��ʼ����
        StartFalling();
    }

    private void StartFalling()
    {
        HideDirectionIndicators();
        isFalling = true;
    }

    private void FallTree()
    {
        // ������ת�Ƕ�
        float rotationAmount = fallSpeed * Time.deltaTime * fallDirection;

        // Ӧ����ת���Ƶײ�������ת��
        transform.RotateAround(groundPosition, Vector3.forward, rotationAmount);

        // ����Ƿ���ȫ����
        float currentAngle = Mathf.Abs(transform.eulerAngles.z % 360);
        if (currentAngle > 80f && currentAngle < 280f)
        {
            // ��ľ��ȫ���£�����
            Destroy(gameObject, 2.0f);
        }
    }
}