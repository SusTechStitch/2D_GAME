using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ElementInteractionManager : MonoBehaviour
{
    public static ElementInteractionManager Instance;

    [Header("Prefabs")]
    public GameObject steamPrefab; // ����Ԥ����
    public GameObject growingTreePrefab; // ��������ľԤ����

    [Header("Interaction Settings")]
    public float interactionDistance = 1.5f; // Ԫ�ؽ�������
    public float interactionCheckInterval = 0.2f; // ���������

    private List<Element> activeElements = new List<Element>();
    private float lastCheckTime;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void RegisterElement(Element element)
    {
        if (!activeElements.Contains(element))
        {
            activeElements.Add(element);
        }
    }

    public void UnregisterElement(Element element)
    {
        if (activeElements.Contains(element))
        {
            activeElements.Remove(element);
        }
    }

    private void Update()
    {
        // ������ЧԪ������
        activeElements.RemoveAll(e => e == null);

        // �������齻��������ÿ֡�����
        if (Time.time - lastCheckTime < interactionCheckInterval) return;
        lastCheckTime = Time.time;

        // ���Ԫ��֮��Ľ���
        for (int i = 0; i < activeElements.Count; i++)
        {
            for (int j = i + 1; j < activeElements.Count; j++)
            {
                Element elem1 = activeElements[i];
                Element elem2 = activeElements[j];

                // ȷ��Ԫ����Ч
                if (elem1 == null || elem2 == null) continue;

                // ������루����Ԫ�ش�С��
                float distance = Vector2.Distance(
                    elem1.transform.position,
                    elem2.transform.position
                );

                // ������С�������루Ԫ�ذ뾶֮��+������룩
                float minDistance = elem1.GetSize() + elem2.GetSize() + interactionDistance;

                if (distance < minDistance)
                {
                    // ˮ��������������
                    if ((elem1.type == Element.ElementType.Fire && elem2.type == Element.ElementType.Water) ||
                        (elem1.type == Element.ElementType.Water && elem2.type == Element.ElementType.Fire))
                    {
                        CreateSteam(elem1.transform.position, elem2.transform.position);
                        DestroyElement(elem1);
                        DestroyElement(elem2);
                        return; // һ��ֻ����һ�Խ���
                    }

                    // ˮľ����������ľ
                    if ((elem1.type == Element.ElementType.Water && elem2.type == Element.ElementType.Wood) ||
                        (elem1.type == Element.ElementType.Wood && elem2.type == Element.ElementType.Water))
                    {
                        Player owner = elem1.type == Element.ElementType.Water ? elem1.owner : elem2.owner;
                        CreateTree(elem1.transform.position, owner);
                        DestroyElement(elem1);
                        DestroyElement(elem2);
                        return; // һ��ֻ����һ�Խ���
                    }
                }
            }
        }
    }

    private void DestroyElement(Element element)
    {
        if (element != null)
        {
            UnregisterElement(element);
            Destroy(element.gameObject);
        }
    }

    private void CreateSteam(Vector3 pos1, Vector3 pos2)
    {
        Vector3 spawnPos = (pos1 + pos2) / 2;
        GameObject steam = Instantiate(steamPrefab, spawnPos, Quaternion.identity);
        Destroy(steam, 3.0f); // 3�����ʧ
    }

    private void CreateTree(Vector3 position, Player owner)
    {
        // �ҵ�����λ��
        Vector2 groundPos = FindGroundPosition(position);
        GameObject treeObj = Instantiate(growingTreePrefab, groundPos, Quaternion.identity);

        // ��ȡ����ʼ����ľ���
        GrowingTree tree = treeObj.GetComponent<GrowingTree>();
        if (tree != null)
        {
            tree.Initialize(owner);
        }
        else
        {
            Debug.LogError("GrowingTree component not found on tree prefab");
        }
    }

    private Vector2 FindGroundPosition(Vector3 startPos)
    {
        // ���·�������Ѱ�ҵ���
        RaycastHit2D hit = Physics2D.Raycast(startPos, Vector2.down, 10f, LayerMask.GetMask("Ground"));
        if (hit.collider != null)
        {
            return hit.point;
        }

        return startPos; // ���û���ҵ����棬ʹ��ԭʼλ��
    }
}