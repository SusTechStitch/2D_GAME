using UnityEngine;

public class Element : MonoBehaviour
{
    public enum ElementType { Fire, Water, Wood }
    public ElementType type;
    public Player owner;

    private ParticleSystem elementParticles;

    private void Start()
    {
        // ע��Ԫ�ص�������
        if (ElementInteractionManager.Instance != null)
        {
            ElementInteractionManager.Instance.RegisterElement(this);
        }

        // ����Ԫ���Ӿ�Ч��
        ApplyElementEffects();
    }

    private void ApplyElementEffects()
    {
        elementParticles = GetComponent<ParticleSystem>();
        if (elementParticles == null) return;

        var main = elementParticles.main;

        switch (type)
        {
            case ElementType.Fire:
                main.startColor = new Color(1f, 0.3f, 0f); // ��ɫ����
                break;
            case ElementType.Water:
                main.startColor = new Color(0.2f, 0.5f, 1f); // ��ɫˮ��
                break;
            case ElementType.Wood:
                main.startColor = new Color(0.2f, 0.8f, 0.3f); // ��ɫ��Ҷ
                break;
        }
    }

    private void OnDestroy()
    {
        // �ӹ�����ע��
        if (ElementInteractionManager.Instance != null)
        {
            ElementInteractionManager.Instance.UnregisterElement(this);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // ����Ԫ�����Ͳ�����ͬ�Ļ���Ч��
        switch (type)
        {
            case ElementType.Fire:
                HandleFireEffect(other);
                break;
            case ElementType.Water:
                HandleWaterEffect(other);
                break;
            case ElementType.Wood:
                HandleWoodEffect(other);
                break;
        }
    }

    private void HandleFireEffect(Collider2D other)
    {
        
    }

    private void HandleWaterEffect(Collider2D other)
    {
       
    }

    private void HandleWoodEffect(Collider2D other)
    {
        
        
    }

    // ��ȡԪ�صı߽�ߴ磨���ھ����⣩
    public float GetSize()
    {
        Collider2D collider = GetComponent<Collider2D>();
        if (collider != null)
        {
            if (collider is CircleCollider2D circle)
            {
                return circle.radius;
            }
            else if (collider is BoxCollider2D box)
            {
                return Mathf.Max(box.size.x, box.size.y) / 2f;
            }
        }
        return 0.5f; // Ĭ��ֵ
    }
}