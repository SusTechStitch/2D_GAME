using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : Entity
{
    public bool isBusy { get; private set; }
    [Header("Attack Details")]
    public Vector2[] AttackMovement;
    public float counterAttackDuration = .2f;

    [Header("Move Info")]
    public float movespeed = 12f;
    public float jumpforce;
    public float SwordReturnImpact;

    [Header("Dash Info")]
    public float dashSpeed;
    public float dashDuration;
    public float dashDir { get; private set; }

    [Header("Element Settings")]
    public float elementDistance = 1.5f; // Ԫ������ҵľ���
    public GameObject[] elementPrefabs; // 0:��, 1:ˮ, 2:ľ
    public Transform elementHolder; // Ԫ�ظ����λ�òο���

    private GameObject currentElement; // ��ǰ���ɵ�Ԫ��
    private ElementType currentElementType = ElementType.None;

    // Ԫ������ö��
    public enum ElementType { None, Fire, Water, Wood }

    public SkillManager skill { get; private set; }
    public GameObject sword { get; private set; }

    // ����ϵͳ�ӿ�
    public PlayerInputHandler InputHandler { get; private set; }

    #region States
    public PlayerStateMachine statemachine { get; private set; }
    public PlayerIdolState idolstate { get; private set; }
    public PlayerMoveState moveState { get; private set; }
    public PlayerJumpState JumpState { get; private set; }
    public PlayerAirState AirState { get; private set; }
    public PlayerWallSlideState WallSlideState { get; private set; }
    public PlayerWallJumpState WallJumpState { get; private set; }
    public PlayerDashState DashState { get; private set; }
    public PlayerPrimaryAttack PrimaryAttack { get; private set; }
    public PlayerCounterAttackState CounterAttack { get; private set; }
    public PlayerAimSwordState AimSword { get; private set; }
    public PlayerCatchSwordState CatchSword { get; private set; }
    #endregion

    // ��ʼ���������ϵͳ
    public void InitializePlayer(PlayerInputHandler inputHandler)
    {
        InputHandler = inputHandler;
    }

    protected override void Awake()
    {
        base.Awake();

        statemachine = new PlayerStateMachine();

        // ��ʼ������״̬
        idolstate = new PlayerIdolState(this, statemachine, "isIdol");
        moveState = new PlayerMoveState(this, statemachine, "isMove");
        JumpState = new PlayerJumpState(this, statemachine, "Jump");
        AirState = new PlayerAirState(this, statemachine, "Jump");
        WallSlideState = new PlayerWallSlideState(this, statemachine, "WallSlide");
        WallJumpState = new PlayerWallJumpState(this, statemachine, "Jump");
        DashState = new PlayerDashState(this, statemachine, "Dash");
        PrimaryAttack = new PlayerPrimaryAttack(this, statemachine, "Attack");
        CounterAttack = new PlayerCounterAttackState(this, statemachine, "CounterAttack");
        AimSword = new PlayerAimSwordState(this, statemachine, "AimSword");
        CatchSword = new PlayerCatchSwordState(this, statemachine, "CatchSword");


    }
    protected override void Start()
    {
        base.Start();
        skill = SkillManager.instance;
        statemachine.Initialize(idolstate);
        CreateElementHolder();
    }

    protected override void Update()
    {
        base.Update();
        statemachine.currentstate.Update();
        CheckforDashInput();
        if (InputHandler != null && InputHandler.ElementSummonPressed())
        {
            SummonElement();
        }

        // ����������Ԫ��λ�ã�������ڣ�
        UpdateElementPosition();
    }

    private void CreateElementHolder()
    {
        // ����Ԫ�ظ���ο���
        GameObject holder = new GameObject("ElementHolder");
        holder.transform.SetParent(transform);

        // ������ҷ������ó�ʼλ��
        float offsetX = facingDir == 1 ? elementDistance : -elementDistance;
        holder.transform.localPosition = new Vector3(offsetX, 0.5f, 0);

        elementHolder = holder.transform;
    }

    // �����������ٻ�Ԫ��
    private void SummonElement()
    {
        // �����Ҵ���æµ״̬��������Ԫ��
        if (isBusy)
            return;

        // �����ǰ��Ԫ�أ�������
        if (currentElement != null)
        {
            Destroy(currentElement);
        }

        // ѭ������һ��Ԫ������
        switch (currentElementType)
        {
            case ElementType.None:
                currentElementType = ElementType.Fire;
                break;
            case ElementType.Fire:
                currentElementType = ElementType.Water;
                break;
            case ElementType.Water:
                currentElementType = ElementType.Wood;
                break;
            case ElementType.Wood:
                currentElementType = ElementType.Fire;
                break;
        }

        // ������Ԫ��
        CreateCurrentElement();
    }

    private void CreateCurrentElement()
    {
        int prefabIndex = (int)currentElementType - 1;
        if (prefabIndex >= 0 && prefabIndex < elementPrefabs.Length)
        {
            currentElement = Instantiate(
                elementPrefabs[prefabIndex],
                elementHolder.position,
                elementHolder.rotation
            );

            // ����Ԫ��Ϊ�ο�����Ӷ���
            currentElement.transform.SetParent(elementHolder);
        }
    }

    // ��������������Ԫ��λ��
    private void UpdateElementPosition()
    {
        if (currentElement != null )
        {
            // ȷ��Ԫ�ظ�����ҷ���
            currentElement.transform.position = elementHolder.position;
            currentElement.transform.rotation = elementHolder.rotation;
        }
    }

    public void AssignNewSword(GameObject _newSword)
    {
        sword = _newSword;
    }

    public void CatchTheSword()
    {
        statemachine.ChangeState(CatchSword);
        Destroy(sword);
    }

    public IEnumerator BusyFor(float _seconds)
    {
        isBusy = true;
        yield return new WaitForSeconds(_seconds);
        isBusy = false;
    }

    public void AnimationTrigger() => statemachine.currentstate.AnimationFinishTrigger();

    private void CheckforDashInput()
    {
        if (isWallDetected())
        {
            return;
        }

        // ʹ������ϵͳ����̰���
        if (InputHandler.DashPressed() && SkillManager.instance.dash.CanUseSkill())
        {
            dashDir = InputHandler.GetHorizontalRaw();
            if (dashDir == 0)
            {
                dashDir = facingDir;
            }
            statemachine.ChangeState(DashState);
        }
    }
}