using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStateMachine : MonoBehaviour
{

    public PlayerState currentstate { get; private set; }

    public void Initialize ( PlayerState _startstate )
    {
        currentstate = _startstate;
        currentstate.Enter(); 
    }

    public void ChangeState( PlayerState _newstate )
    {
        currentstate.Exit();
        currentstate = _newstate;
        currentstate.Enter(); 
    }
}
