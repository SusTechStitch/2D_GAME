using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkeletonMoveState : SkeletonGroundedState
{
    public SkeletonMoveState(Enemy _enemyBase, EnemyStateMachine _StateMachine, string _AnimeboolName, Enemy_Skeleton _enemy) : base(_enemyBase, _StateMachine, _AnimeboolName, _enemy)
    {
    }

    public override void Enter()
    {
        base.Enter();
    }

    public override void Exit()
    {
        base.Exit();
    }

    public override void Update()
    {
        base.Update();
        enemy.SetVelocity(enemy.moveSpeed * enemy.facingDir, rb.velocity.y);

        if ( enemy.isWallDetected() || !enemy.isGroundedDetected())
        {
            enemy.Flip();

            StateMachine.ChangeState(enemy.idolState); 
        }

    }
}
