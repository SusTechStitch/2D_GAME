using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkeletonBattleState : EnemyState
{

    private Transform player; 
    private Enemy_Skeleton enemy;
    private int moveDir;



    public SkeletonBattleState(Enemy _enemyBase, EnemyStateMachine _StateMachine, string _AnimeboolName, Enemy_Skeleton _enemy) : base(_enemyBase, _StateMachine, _AnimeboolName)
    {
        this.enemy = _enemy;
    }

    public override void Enter()
    {
        base.Enter();

        player = PlayerManager.instance.player.transform;
    }

    public override void Exit()
    {
        base.Exit();
    }

    public override void Update()
    {
        base.Update();

        if (enemy.isPlayerDetected())
        {
            StateTimer = enemy.battleTime;

            if( enemy.isPlayerDetected().distance < enemy.attackDistance )
            {
                if ( CanAttack())
                {
                    StateMachine.ChangeState(enemy.attackState);
                }
            }
        }
        else
        {
            if (StateTimer < 0 || Vector2.Distance(player.transform.position , enemy.transform.position) > 10 )
            {
                StateMachine.ChangeState(enemy.idolState);
            }
        }

        if (player.position.x > enemy.transform.position.x)
        {
            moveDir = 1;
        }
        else if (player.position.x < enemy.transform.position.x)
        {
            moveDir = -1;
        }

        enemy.SetVelocity(enemy.moveSpeed * moveDir, rb.velocity.y);

    }


    private bool CanAttack()
    {
        if (Time.time >= enemy.lastTimeAttacked + enemy.attackCoolDown )
        {
            enemy.lastTimeAttacked = Time.time;
            return true; 
        }

        return false;
    }




}
