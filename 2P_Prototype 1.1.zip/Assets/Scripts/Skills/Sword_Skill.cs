using System.Collections;
using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine;

public class Sword_Skill : Skill
{

    [Header("Skill Info")]
    [SerializeField] private GameObject swordprefab;
    [SerializeField] private Vector2 LaunchDir;
    [SerializeField] private float SwordGravity;


    private Vector2 finDir;

    [Header("Aim Dots")]
    [SerializeField] private int NumborOfDots;
    [SerializeField] private float SpaceBetweenDots;
    [SerializeField] private GameObject DotPrefab;
    [SerializeField] private Transform DotsParent;

    private GameObject[] dots;


    protected override void Start()
    {
        base.Start();

        GenerateDots();
    }

    protected override void Update()
    {
        if ( Input.GetKeyUp(KeyCode.Mouse1))
        {
            finDir = new Vector2(AimDirection().normalized.x * LaunchDir.x, AimDirection().normalized.y * LaunchDir.y);
        }

        if ( Input.GetKey(KeyCode.Mouse1))
        {
            for ( int i = 0; i < dots.Length; i++ )
            {
                dots[i].transform.position = DotsPosition(i * SpaceBetweenDots);
            }
        }
    }


    public void CreateSword()
    {
        GameObject newSword = Instantiate(swordprefab, player.transform.position, transform.rotation);
        Sword_Skill_Controller newSwordScript = newSword.GetComponent<Sword_Skill_Controller>();

        newSwordScript.SetUpSword(finDir, SwordGravity, player);

        player.AssignNewSword(newSword);

        DotsActive(false);
    }

    public Vector2 AimDirection ()
    {
        Vector2 playerposition = player.transform.position;
        Vector2 mouseposition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector2 direction = mouseposition - playerposition;

        return direction; 
    }

    public void DotsActive(bool _isActive)
    {
        for ( int i = 0; i < dots.Length; i++ )
        {
            dots[i].SetActive(_isActive);
        }
    }

    private void GenerateDots()
    {
        dots = new GameObject[NumborOfDots];
        for ( int i = 0; i < NumborOfDots; i ++ )
        {
            dots[i] = Instantiate(DotPrefab, player.transform.position, Quaternion.identity, DotsParent);
            dots[i].SetActive(false);
        }
    }

    private Vector2 DotsPosition(float T)
    {
        Vector2 position = (Vector2)player.transform.position + new Vector2(
            AimDirection().normalized.x * LaunchDir.x,
            AimDirection().normalized.y * LaunchDir.y) * T + .5f*(Physics2D.gravity * SwordGravity) * (T * T);

        return position; 
    }


}
