// GrowingTree.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GrowingTree : MonoBehaviour
{
    [Header("Growth Settings")]
    public float growthSpeed = 1.0f;
    public float maxHeight = 8.0f;
    public float maxGrowthTime = 5.0f;

    [Header("Fall Settings")]
    public float fallSpeed = 60.0f; // �����ٶȣ���/�룩

    private Player owner;
    private float currentHeight;
    private float growthTimer;
    private bool isGrowing = true;
    private bool isFalling;
    private float fallDirection; // -1 ����1 ����

    public void Initialize(Player player)
    {
        owner = player;
        currentHeight = 0.1f;
        growthTimer = maxGrowthTime;
        UpdateTreeVisual();
    }

    private void Update()
    {
        if (isGrowing)
        {
            GrowTree();
        }
        else if (isFalling)
        {
            FallTree();
        }
    }

    private void GrowTree()
    {
        // ���Ӹ߶�
        currentHeight += growthSpeed * Time.deltaTime;
        currentHeight = Mathf.Min(currentHeight, maxHeight);

        // ��������ʱ��
        growthTimer -= Time.deltaTime;

        // ������ľ�Ӿ�
        UpdateTreeVisual();

        // ����Ƿ�ֹͣ����
        if (currentHeight >= maxHeight || growthTimer <= 0)
        {
            StopGrowing();
        }
    }

    private void UpdateTreeVisual()
    {
        // �������ɸ߶�
        Transform trunk = transform.Find("Trunk");
        if (trunk != null)
        {
            trunk.localScale = new Vector3(0.5f, currentHeight, 1);
            trunk.localPosition = new Vector3(0, currentHeight / 2, 0);
        }

        // ��������λ��
        Transform canopy = transform.Find("Canopy");
        if (canopy != null)
        {
            canopy.localPosition = new Vector3(0, currentHeight, 0);
        }
    }

    private void StopGrowing()
    {
        isGrowing = false;

        // ��ʾ����ָʾ��
        ShowDirectionIndicators();

        // ��ʼ��������
        StartCoroutine(WaitForDirectionInput());
    }

    private void ShowDirectionIndicators()
    {
        // ��ʾ���ҷ���ָʾ��
        Transform leftIndicator = transform.Find("LeftIndicator");
        Transform rightIndicator = transform.Find("RightIndicator");

        if (leftIndicator != null) leftIndicator.gameObject.SetActive(true);
        if (rightIndicator != null) rightIndicator.gameObject.SetActive(true);
    }

    private void HideDirectionIndicators()
    {
        // ���ط���ָʾ��
        Transform leftIndicator = transform.Find("LeftIndicator");
        Transform rightIndicator = transform.Find("RightIndicator");

        if (leftIndicator != null) leftIndicator.gameObject.SetActive(false);
        if (rightIndicator != null) rightIndicator.gameObject.SetActive(false);
    }

    private IEnumerator WaitForDirectionInput()
    {
        bool directionSelected = false;

        while (!directionSelected)
        {
            if (owner != null && owner.InputHandler.TreeConfirmPressed())
            {
                // ��ȡ���λ��
                Vector2 mouseWorldPos = Camera.main.ScreenToWorldPoint(owner.InputHandler.GetMousePosition());

                // ȷ�����µķ���
                fallDirection = mouseWorldPos.x > transform.position.x ? 1 : -1;
                directionSelected = true;
            }
            yield return null;
        }

        // ��ʼ����
        StartFalling();
    }

    private void StartFalling()
    {
        HideDirectionIndicators();
        isFalling = true;
    }

    private void FallTree()
    {
        // ������ת�Ƕ�
        float rotationAmount = fallSpeed * Time.deltaTime * fallDirection;

        // Ӧ����ת
        transform.Rotate(0, 0, rotationAmount);

        // ����Ƿ���ȫ����
        if (Mathf.Abs(transform.eulerAngles.z) > 80f || Mathf.Abs(transform.eulerAngles.z - 360f) < 280f)
        {
            // ��ľ��ȫ���£�����
            Destroy(gameObject, 2.0f); // 2�������
            enabled = false; // ���ýű�
        }
    }
}