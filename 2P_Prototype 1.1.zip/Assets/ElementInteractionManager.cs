// ElementInteractionManager.cs
using UnityEngine;
using System.Collections.Generic;

public class ElementInteractionManager : MonoBehaviour
{
    public static ElementInteractionManager Instance;

    [Header("Prefabs")]
    public GameObject steamPrefab; // ����Ԥ����
    public GameObject growingTreePrefab; // ��������ľԤ����

    private List<Element> activeElements = new List<Element>();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void RegisterElement(Element element)
    {
        activeElements.Add(element);
    }

    public void UnregisterElement(Element element)
    {
        activeElements.Remove(element);
    }

    private void Update()
    {
        // ���Ԫ��֮��Ľ���
        for (int i = 0; i < activeElements.Count; i++)
        {
            for (int j = i + 1; j < activeElements.Count; j++)
            {
                Element elem1 = activeElements[i];
                Element elem2 = activeElements[j];

                // �������Ƿ��㹻��
                float distance = Vector2.Distance(elem1.transform.position, elem2.transform.position);
                if (distance < 2.0f)
                {
                    // ˮ��������������
                    if ((elem1.type == Element.ElementType.Fire && elem2.type == Element.ElementType.Water) ||
                        (elem1.type == Element.ElementType.Water && elem2.type == Element.ElementType.Fire))
                    {
                        CreateSteam(elem1.transform.position, elem2.transform.position);
                        Destroy(elem1.gameObject);
                        Destroy(elem2.gameObject);
                        return; // һ��ֻ����һ�Խ���
                    }

                    // ˮľ����������ľ
                    if ((elem1.type == Element.ElementType.Water && elem2.type == Element.ElementType.Wood) ||
                        (elem1.type == Element.ElementType.Wood && elem2.type == Element.ElementType.Water))
                    {
                        Player owner = elem1.type == Element.ElementType.Water ? elem1.owner : elem2.owner;
                        CreateTree(elem1.transform.position, owner);
                        Destroy(elem1.gameObject);
                        Destroy(elem2.gameObject);
                        return; // һ��ֻ����һ�Խ���
                    }
                }
            }
        }
    }

    private void CreateSteam(Vector3 pos1, Vector3 pos2)
    {
        Vector3 spawnPos = (pos1 + pos2) / 2;
        GameObject steam = Instantiate(steamPrefab, spawnPos, Quaternion.identity);
        Destroy(steam, 3.0f); // 3�����ʧ
    }

    private void CreateTree(Vector3 position, Player owner)
    {
        // �ҵ�����λ��
        Vector2 groundPos = FindGroundPosition(position);
        GameObject treeObj = Instantiate(growingTreePrefab, groundPos, Quaternion.identity);
        GrowingTree tree = treeObj.GetComponent<GrowingTree>();
        tree.Initialize(owner);
    }

    private Vector2 FindGroundPosition(Vector3 startPos)
    {
        // ���·�������Ѱ�ҵ���
        RaycastHit2D hit = Physics2D.Raycast(startPos, Vector2.down, 10f, LayerMask.GetMask("Ground"));
        if (hit.collider != null)
        {
            return hit.point;
        }
        return startPos; // ���û���ҵ����棬ʹ��ԭʼλ��
    }
}