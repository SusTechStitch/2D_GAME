using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayController : MonoBehaviour
{
    public float runSpeed;
    public float jumpSpeed;
    private Rigidbody2D myRigidbody;
    private Animator myAnim;
    private BoxCollider2D myFeet;
    private bool isGround;


    // Start is called before the first frame update
    void Start()
    {
        myRigidbody = GetComponent<Rigidbody2D>();
        myAnim = GetComponent<Animator>();
        myFeet = GetComponent<BoxCollider2D>();
    }

    // Update is called once per frame
    void Update()
    {
        run();
        //flip();
        jump();
        CheckGround();
        SwitchAnimation();
    }
    void CheckGround()
    {
        isGround = myFeet.IsTouchingLayers(LayerMask.GetMask("Ground"));
        Debug.Log(isGround);
    }

    void flip()
    {
        bool playerHasXAxisSpeed =Mathf.Abs(myRigidbody.velocity.x)>Mathf.Epsilon;
        if(playerHasXAxisSpeed)
        {
            transform.localRotation = Quaternion.Euler(0,0,0);
            if(myRigidbody.velocity.x>0.1f)
            {
                transform.localRotation = Quaternion.Euler(0,0,0);
            }
            if(myRigidbody.velocity.x<-0.1f)
            {
                transform.localRotation = Quaternion.Euler(0,100,0);
            }
        }
        
    }
    void run()
    {
        float movedir = Input.GetAxis("Horizontal");
        Vector2 playerVel = new Vector2(movedir * runSpeed,myRigidbody.velocity.y);
        myRigidbody.velocity =playerVel;
        bool playerHasXAxisSpeed = Mathf.Abs(myRigidbody.velocity.x)>Mathf.Epsilon;
        myAnim.SetBool("run",playerHasXAxisSpeed);
    }

    void jump()
    {
        if(Input.GetKeyDown(KeyCode.W))
        {
            if(isGround)
            {
                myAnim.SetBool("jump",true);
                Vector2 jumpVal = new Vector2(0.0f,jumpSpeed);
                myRigidbody.velocity=Vector2.up * jumpVal;
            }
        }
    }
    void SwitchAnimation()
    {
       // myAnim.SetBool("jump",false);
        if(myAnim.GetBool("jump"))
        {
            if(myRigidbody.velocity.y==0)
            {
                 myAnim.SetBool("jump",false);
            }
        }
    }
}
