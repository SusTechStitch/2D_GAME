using UnityEngine;

public class SteamGeneration : MonoBehaviour
{
    [Header("Settings")]
    public GameObject targetObject;
    public GameObject objectToSpawn;
    public float growDuration = 2f;
    public KeyCode startKey = KeyCode.E;
    public bool destroyAfterGrowth = true;

    private bool isGrowing = false;
    private GameObject spawnedObject;
    private float growTimer;

    void Update()
    {
        if (Input.GetKeyDown(startKey))
        {
            if (isGrowing)
            {
                // ��ǰ���������پɶ���
                if (spawnedObject != null)
                {
                    Destroy(spawnedObject);
                    spawnedObject = null;
                }
                isGrowing = false;
            }

            StartGrowing();
        }

        if (isGrowing)
        {
            ScaleOverTime();
        }
    }

    void StartGrowing()
    {
        if (targetObject == null || objectToSpawn == null)
        {
            Debug.LogWarning("TargetObject �� ObjectToSpawn δ���ã�");
            return;
        }

        spawnedObject = Instantiate(
            objectToSpawn,
            targetObject.transform.position,
            Quaternion.identity
        );
        spawnedObject.transform.localScale = Vector3.zero;
        growTimer = 0f;
        isGrowing = true;
    }

    void ScaleOverTime()
    {
        if (spawnedObject == null)
        {
            isGrowing = false;
            return;
        }

        growTimer += Time.deltaTime;
        float t = Mathf.Clamp01(growTimer / growDuration);
        float smoothT = Mathf.SmoothStep(0f, 1f, t);

        Vector3 targetScale = targetObject.transform.lossyScale * 2f;
        spawnedObject.transform.localScale = Vector3.Lerp(
            Vector3.zero,
            targetScale,
            smoothT
        );

        if (growTimer >= growDuration)
        {
            isGrowing = false;

            if (destroyAfterGrowth && spawnedObject != null)
            {
                Destroy(spawnedObject, 0.5f);
                spawnedObject = null;
            }

            Debug.Log("������ɣ������ã�");
        }
    }
}
